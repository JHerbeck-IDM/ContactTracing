import numpy as np
import pandas as pd
import networkx as nx
import argparse

"""Functions for reanding in the transmission "edge" list csv file
and created the (observed) phylotree"""

def readLineList(filename):
    """This function reads the edge list (csv) into a pandas dataframe.
    The file read in at least has to have columns named 'id', 'infectedTime',
    and 'infectedById'"""

    lineList = pd.read_csv(filename)
    lineList['id'] = lineList['id'].astype(str)
    lineList['infectedById'] = lineList['infectedById'].astype(str)

    return lineList

def transTreeFromLineList(lineList, ID='id', infectorID='infectedById', time='timeInfected', branchLength=False):
    """This function uses the edge list to create the transmission tree.
    At this stage rather than calculating the branch length each node
    has an attribute indicating when it was infected."""

    nodes = list(zip(lineList[ID], [{'time': x} for x in lineList[time]]))
    transmissionTree = nx.DiGraph()
    transmissionTree.add_nodes_from(nodes)
    roots = set(lineList[infectorID]) - set(transmissionTree.nodes())
    transmissionTree.add_nodes_from(roots, time=np.min(lineList[time]))
    transmissionTree.add_edges_from(list(zip(lineList[infectorID], lineList[ID])), weight=0)
    if(branchLength):
        calcBranchLength(transmissionTree)

    return transmissionTree

def selectSampleNodes(tree, param=100, method='number'):
    """This is a random observation model. The actually observation model should go here."""

    sampleNodes = tree.nodes
    if method == 'number':
        sampleNodes = np.random.choice(sampleNodes, param, replace=False)
    elif method == 'fraction':
        idx = np.ones(len(sampleNodes))/param > np.random.rand(len(sampleNodes))
        sampleNodes = sampleNodes[idx]
    else:
        print('No sampling type:', method)
        exit(-1)

    return sampleNodes

def getDownsampledTree(transmissionTree, sampledNodes):
    """Remove all nodes that are not sampled nodes or on the path from
    sampled nodes to the root nodes"""

    try:
        nx.find_cycle(transmissionTree)
        print("ERROR: There is a cycle in your tree!")
        return(-1)
    except:
        pass

    nodesToKeep = set(sampledNodes)
    for node in sampledNodes:
        ancestralNode = list(transmissionTree.predecessors(node))
        while len(ancestralNode) > 0:
            nodesToKeep.add(ancestralNode[0])
            ancestralNode = list(transmissionTree.predecessors(ancestralNode[0]))

    nodesToRemove = set(transmissionTree.nodes)
    nodesToRemove = nodesToRemove - nodesToKeep
    downsampledTree = transmissionTree.copy()
    downsampledTree.remove_nodes_from(nodesToRemove)

    return downsampledTree

def phyloTreeFromTransTree(downsampledTransmissionTree, sampledNodes, leaves=True, bifurcate=True):
    """Turn the downsampled transmission tree into the phylo tree"""

    phyloTree = downsampledTransmissionTree.copy()

    if leaves:
        makeSamplesLeaves(phyloTree, sampledNodes)

    if bifurcate:
        eliminateMultifurcation(phyloTree)

    prune(phyloTree, sampledNodes, False, True)

    joinSubtrees(phyloTree)

    prune(phyloTree, sampledNodes, False)

    if bifurcate:
        makeMonoSamplesLeaves(phyloTree, sampledNodes)

    calcBranchLength(phyloTree)

    return phyloTree

def prune(tree, sampledNodes=None, branchLength=True, keepRoot=False):
    """This function prunes nodes from the tree that are not
    sampled, root, or internal nodes with more than one child.
    You can choose whether or not to update the branch lengths
    when you run the prune or to calculate them later by calling
    calcBranchLength. If you are doing multiple things it will
    be faster to skip calculating the branch length until after
    everything is complete."""

    if(sampledNodes==None):
        sampledNodes = [n for n,d in tree.out_degree() if d==0]

    nonsampledNodes = set(tree.nodes) - set(sampledNodes)
    roots = []
    while(True):
        removed = set();

        #remove all nodes with only 1 child and leaf nodes that
        #are not sampled and are not a root
        for node in nonsampledNodes:
            successors = list(tree.successors(node))
            predecessor = list(tree.predecessors(node))
            if(len(predecessor)==0):
                roots.append(node)
            if len(successors)<2:
                if len(predecessor)>0 and len(successors)>0:
                    predecessor = predecessor[0]
                    successors = successors[0]
                    tree.add_edge(predecessor, successors)
                    tree.remove_node(node)
                elif len(successors)==0:
                    tree.remove_node(node)
                elif len(predecessor)==0 and not keepRoot:
                    tree.remove_node(node)
                removed.add(node)

        nonsampledNodes = nonsampledNodes - removed
        if len(removed) == 0:
            break

    ## The above does not remove single children of the
    ## root. Here we check for that.
    #for root in roots:
    #    successors = list(tree.successors(root))
    #    while(len(successors)==1):
    #        if(successors[0] in sampledNodes):
    #            successors.append(successors[0])
    #        else:
    #            for child in tree.successors(successors[0]):
    #                tree.add_edge(root, child)
    #            tree.remove_node(successors[0])
    #            successors = list(tree.successors(root))

    if(branchLength):
        calcBranchLength(tree)

    return

def makeSamplesLeaves(tree, sampledNodes):
    """Add a fictious internal node as the parent of
    any sampled node that has children so the sampled
    node can be a leaf node."""

    out_degree = tree.out_degree(sampledNodes)
    for node, degree in out_degree:
        if degree>0:
            predecessor = list(tree.predecessors(node))[0]
            successors = list(tree.successors(node))
            tree.add_node(str(node)+"_anc", time=tree.nodes[node]['time'])
            tree.add_edge(predecessor, str(node)+"_anc", weight=0)
            tree.add_edge(str(node)+"_anc", node, weight=0)
            tree.remove_edge(predecessor, node)
            for i in successors:
                tree.add_edge(str(node)+"_anc", i)
                tree.remove_edge(node, i)

    return

def makeMonoSamplesLeaves(tree, sampledNodes):
    """Add a fictious internal node as the parent of
    any sampled node that has one children to remove
    monofurcating internal nodes that sholud not be
    directly removed themselves."""

    out_degree = tree.out_degree(sampledNodes)
    for node, degree in out_degree:
        if degree==1:
            successors = list(tree.successors(node))
            predecessor = list(tree.predecessors(node))
            tree.add_node(str(node)+"_anc", time=tree.nodes[node]['time'])
            tree.add_edge(str(node)+"_anc", node, weight=0)

            # If not root fix parent node to be parent of the new node instead
            if len(predecessor)>0:
                predecessor = predecessor[0]
                tree.add_edge(predecessor, str(node)+"_anc", weight=0)
                tree.remove_edge(predecessor, node)
            # This for loop is unnecessary as there should only be one successor
            for i in successors:
                tree.add_edge(str(node)+"_anc", i)
                tree.remove_edge(node, i)

    return

def eliminateMultifurcation(tree):
    """Eliminate multifurcation by adding fictious nodes if there
    is a node with more than 2 children."""

    # Find all multifurcating nodes
    nodes = [node for node, degree in (tree.out_degree(tree.nodes)) if degree>2]

    # Add new nodes to break multifurcation into a series
    # of bifurcations.
    for node in nodes:
        successors = list(tree.successors(node))
        anc = node
        while len(successors)>2:
            successors.remove(np.random.choice(successors))
            tree.add_node(anc+'_desc', time=tree.nodes[anc]['time'])
            tree.add_edge(anc, anc+'_desc')
            for succ in successors:
                tree.add_edge(anc+'_desc', succ, weight=0)
                tree.remove_edge(anc, succ)
            anc = anc+'_desc'
            successors = list(tree.successors(anc))

    return

def makeBifurcating(tree, branchLength=True, sampledNodes=None):
    """Make a tree a bifurcating tree."""

    eliminateMultifurcation(tree)
    prune(tree, sampledNodes, branchLength)
    makeMonoSamplesLeaves(tree, sampledNodes)
    return

def getPopSize(tree, roots):
    """Estimate the population size for each disconnected tree.
    We will then add the population sizes together to estimate
    the population size for the full connected tree."""

    pop_size = np.zeros(len(roots))

    for i in range(len(roots)):
        # We need to iterate over the tree by time.
        successors = dict(nx.bfs_successors(tree, roots[i]))
        nodes = sum(successors.values(), [])
        n = len(nodes)-len(successors) + 1

        # Get the indices needed for the time array to be
        # sorted.
        time_graph = tree.subgraph(nodes)
        nodes, times = zip(*time_graph.nodes('time'))
        idx_sort = np.argsort(times)
        N = 0
        k = len(list(tree.successors(roots[i])))
        # Iterate forward (skipping the root node) keeping
        # track of the number of lineages and calculating
        # the appropriate contribution to the MLE theta estimate.
        for idx in range(1, len(idx_sort)):
            N += k*(k-1)*(times[idx_sort[idx]] - times[idx_sort[idx-1]])
            k = k - 1 + len(list(tree.successors(nodes[idx_sort[idx]])))

        # Normalize based on number of coalescent events
        if n>1:
            pop_size[i] = N/(n-1)
        else:
            # If there is only one linage we will get
            # a divide by zero error. Instead set
            # N to 0 for this subtree.
            pop_size[i] = 0

    # Sum the individual population estimates from
    # each tree
    N = sum(pop_size)

    return N

def joinSubtrees(tree, branchLength=False):
    """Find the roots for all subtrees and join them
    into a single tree. The times for the joining nodes
    will be estimated using serial-smaple coalescence."""

    # Find all roots
    nodes, in_degree = zip(*tree.in_degree())
    idx = np.flatnonzero(np.in1d(in_degree, 0))
    roots = []
    for i in range(len(idx)):
        roots.append(nodes[idx[i]])

    # Estimate population size
    N = getPopSize(tree, roots)

    # Randomly coalesce roots until there
    # is only one.
    k = len(roots)
    for i in range(1,k):
        nodes = np.random.choice(roots, size=2, replace=False)
        new_node = 'JOIN_' + str(nodes[0]) + '_' + str(nodes[1])
        t = min(tree.nodes[nodes[0]]['time'], tree.nodes[nodes[1]]['time']) - np.random.exponential(N/(k*(k-1)))
        tree.add_node(new_node, time=t)
        tree.add_edge(new_node, nodes[0], weight=0)
        tree.add_edge(new_node, nodes[1], weight=0)
        roots.append(new_node)
        roots.remove(nodes[0])
        roots.remove(nodes[1])

    if(branchLength):
        calcBranchLength(tree)

    return

def calcBranchLength(tree):
    """Calculate branch lengths (weights) from the time
    attribute of each node."""

    # Find the roots(s)
    nodes, in_degree = zip(*tree.in_degree())
    idx = np.flatnonzero(np.in1d(in_degree, 0))
    roots = []
    for i in range(len(idx)):
        roots.append(nodes[idx[i]])

    # Calculate branch lengths
    for i in range(len(roots)):
        successors = dict(nx.bfs_successors(tree, roots[i]))
        nodes = sum(successors.values(), [])
        for parent in successors:
            for child in successors[parent]:
                tree[parent][child]['weight'] = tree.nodes[child]['time'] - tree.nodes[parent]['time']
    return

def tree_to_newick(tree, nodes):
    """Private function for recursively building the Newick string"""

    items = []
    for n in nodes:
        s = ''
        children = list(tree.successors(n))
        subt = tree_to_newick(tree, children)
        if subt != '':
            s += '(' + subt + ')'
        s += n + ':' + str(tree[list(tree.predecessors(n))[0]][n]['weight'])
        items.append(s)

    return ','.join(items)

def getNewickString(tree):
    """Get the tree as a Newick string for writing to file or
    passing to other programs"""

    #remove priveleged characters in the Newick format
    node_names = list(tree.nodes)
    node_names = [node.replace(':', '_') for node in node_names]
    node_names = [node.replace(',', '-') for node in node_names]
    node_names = [node.replace(';', '+') for node in node_names]
    mapping = dict(zip(tree, node_names))
    nx.relabel_nodes(tree, mapping, copy=False)

    nodes, in_degree = zip(*tree.in_degree())
    idx = np.in1d(in_degree, 0)
    root = np.array(nodes)[idx]
    if len(root) != 1:
        print("Wrong number of roots (", len(root), "). Something went wrong with the joining process.")
        return -1

    #Find children and build substrings
    children = list(tree.successors(root[0]))
    return '(' + tree_to_newick(tree, children) + ')' + str(root[0]) + ':0;'

def writeTreeToFile(tree, filename):
    """Write tree to file in Newick format"""

    newick = getNewickString(tree)
    writeNewickString(newick, filename)

def writeNewickString(newick, filename):
    """Write newick string to file"""

    fileObj = open(filename, 'w')
    fileObj.write(newick)
    fileObj.close()

def buildTree(lineList, config=None, sampleIds=None, outFile=None, leaves=True, bifurcate=True,
        ID='id', infectorID='infectedById', time='timeInfected'):
    """Staring with the file name for a line list (edge list) create the
    (sampled) phylo tree and write it to disk."""

    #if lineList is a filename (str) read in the data, otherwise
    #assume thath we have been given the line list.
    if type(lineList) is str:
        lineList = readLineList(lineList, ID, infectorID)
    else:
        #make sure the IDs are strings not numbers
        lineList[ID] = lineList[ID].astype(str)
        lineList[infectorID] = lineList[infectorID].astype(str)

    #turn the line list (edge list) into a transmission tree
    tree = transTreeFromLineList(lineList, ID, infectorID, time)

    #get list of sampled nodes
    if config is None:
        #get predetermined list of sampled nodes
        if type(sampleIds) is str:
            #read in the sampled node ids from file
            with open(sampleIds) as f:
                sampledNodes = f.read().splitlines()
                sampledNodes = list(map(str, sampledNodes))
        elif sampleIds is None:
            # This is a catch if no observation model or
            # sample list is supplied
            sampledNodes = selectSampleNodes(tree)
        else:
            #assume sampleNodes is a list and rename
            sampledNodes = list(map(str, sampleIds))
    else:
        #run observation model if given the config file
        from sampling.observationModel import runObservationModel
        sampledNodes = runObservationModel(config, return_ids=True, lineList=lineList)

    #prune the tree based on the sampled nodes
    tree = getDownsampledTree(tree, sampledNodes)

    #finish turning the transmission tree into a phylo tree
    tree = phyloTreeFromTransTree(tree, sampledNodes, leaves=leaves, bifurcate=bifurcate)

    if outFile is None:
        #if there is no file to write the tree to return it
        return tree
    else:
        writeTreeToFile(tree, outFile)

    return

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
            prog='python_phylo_tree_builder',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            description="Python Code for translating transmission trees into phylo trees.")
    parser.add_argument('--config', '-C', metavar='CONFIG_FILE_NAME', help="config file name for observation model.", default=None)
    parser.add_argument('--indata', '-I', metavar='INPUT_LINELIST_FILE_NAME', help="Line list from which to build the tree.", default="infectionLineList.csv")
    parser.add_argument('--outfile', '-O', metavar='OUTPUT_NEWICK_FILE_NAME', help="File name for writing the newick tree to.", default="connectedTree.tre")
    parser.add_argument('--idfile', '-D', metavar='ID_INPUT_FILE_NAME', help="File name containing the node ids to sample.", default=None)
    input_args = parser.parse_args()


    buildTree(input_args.indata, input_args.config, input_args.idfile, input_args.outfile)

