# Python libraries (native, 3rd party)
import numpy
import pandas




def distributions_gaussian( x : pandas.DataFrame ):
    """Draw random samples from a normal (Gaussian) distribution.
    Args:
     x : Pandas DataFrame. Each row contains a set of parameters to be used
         for generating random samples, namely, mu (distribution mean), sigma
         (variance), and n (number of samples).
    """

    # Initialize output array
    nSims    = len(x)
    nSamples = int( x["n"].max() )
    y        = numpy.full( [nSims, nSamples], numpy.nan )



    # Loop through every parameter set and run simulations
    for j in range(0, nSims):

        # Read model parameters
        mu    =      x.loc[j, "mu"   ]
        sigma =      x.loc[j, "sigma"]
        n     = int( x.loc[j, "n"    ] )

        # Draw samples from Gaussian distribution; save results
        y[j,:] = numpy.random.normal( loc=mu, scale=sigma, size=(1,n) )



    # Prepare output and return
    y_df = pandas.DataFrame(y)
    y_df = y_df.add_prefix("z_")
    return y_df
