import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
#TODO add ability to calculate it over different time intervals
def BL_calculate_ratio_median(trees, attr, attr_values, **kwargs):
    """
    Return the ratio of the median internal branch length over the median
    external branch length of a tree or dict of trees. If an attribute is
    provided, this statistic is calculated for all internal/external branch
    lengths and conditionally for each unique value of the attribute.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and building
                               a list of values found in them.

    Returns:
        DataFrame            : Data frame containing the ratio of the median
                               internal branch length and median external branch
                               length of the tree(s), and if attr is provided,
                               the conditional ratio based on the node attribute
                               (as different columns).
    """

    # Initialize output dataframe
    median_BL_ratios_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        in_branch_lengths = []
        ex_branch_lengths = []
        in_node_attrs     = []
        ex_node_attrs     = []
        for node in tree.iter_descendants():
            if node.is_leaf():
                ex_branch_lengths.append(node.dist)
                ex_node_attrs.append(getattr(node.up, attr)) if attr else None
            else:
                in_branch_lengths.append(node.dist)
                in_node_attrs.append(getattr(node.up, attr)) if attr else None
        in_branch_lengths = np.array(in_branch_lengths)
        ex_branch_lengths = np.array(ex_branch_lengths)

        median_BL_ratios_df.loc[name, 'median_ratio_branch_length'] = np.median(in_branch_lengths)/np.median(ex_branch_lengths)
        if attr:
            in_node_attrs = np.array(in_node_attrs)
            ex_node_attrs = np.array(ex_node_attrs)
            for attr_value in attr_values:
                idx = attr_value==in_node_attrs
                idx1 = attr_value==ex_node_attrs
                # If branch_lengths[idx] returns an empty array the numpy functions will fail
                if np.any(idx) and np.any(idx1):
                    median_BL_ratios_df.loc[name, 'median_ratio_branch_length_' + attr_value] = np.median(in_branch_lengths[idx])/np.median(ex_branch_lengths[idx1])
                elif np.any(idx) and not np.any(idx1):
                    median_BL_ratios_df.loc[name, 'median_ratio_branch_length_' + attr_value] = float('inf')
                elif not np.any(idx) and np.any(idx1):
                    median_BL_ratios_df.loc[name, 'median_ratio_branch_length_' + attr_value] = 1.0
                else:
                    median_BL_ratios_df.loc[name, 'median_ratio_branch_length_' + attr_value] = 0.0

    # Finalize and return
    return median_BL_ratios_df
