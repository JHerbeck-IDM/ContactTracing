import numpy as np
import pandas as pd

def closeness_max(trees, **kwargs):
    """
    Return the maximum closeness of the nodes. This can be calculated 
    using branch lengths (default) or topology (number of edges). Additionally
    it can be calculated for the whole tree or conditionally based on the 
    attribute values of attr of the nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the tree height
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of 
                                   branches) instead of branch lengths.

    Returns:
        DataFrame                : The maximum closenss of the nodes for the
                                   whole tree and if an attr is provided, 
                                   conditionally for each unique value of the 
                                   attribute.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False
    
    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that    
    if topology_only:
        feature_name = 'closeness_max_topology'
    else:
        feature_name = 'closeness_max'
		
    # Initialize output dataframe
    closeness_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        nodes = [tree] + tree.get_descendants('levelorder')
        num_nodes = len(nodes)
        # When using get distance with topology_only it counts nodes inbetween
        # the two nodes instead of the number of edges, so it always under 
        # counts by one. So we have to add one to every entry and then 
        # subtract one if it is not topology_only, but we want to make sure the
        # diagonal stays zero. This is the point of this and other if 
        # if statements on topology_only.
        if topology_only:
            distance = np.zeros((num_nodes, num_nodes))
        else:
            distance = np.ones((num_nodes, num_nodes))
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs = []
            for i in np.arange(num_nodes):
                # Get the attribute of the node
                node_attrs.append(getattr(nodes[i], attr))
                for j in np.arange(i+1, num_nodes):
                    distance[i,j] = nodes[i].get_distance(nodes[j], topology_only=topology_only)+1
                    distance[j,i] = distance[i,j]
            if not topology_only:
                distance = distance - 1
            node_attrs = np.array(node_attrs)
            closeness_df.loc[name, feature_name] = np.amax(1/np.sum(distance, axis=1))
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If no attr_value in node_attrs
                if np.sum(idx) == 0:
                    closeness_df.loc[name, feature_name + '_' + attr_value] = 0
                else:
                    closeness_df.loc[name, feature_name + '_' + attr_value] = np.amax(1/np.sum(distance[idx,:][:,idx], axis=1)) 
        else:
            for i in np.arange(num_nodes):
                for j in np.arange(i+1, num_nodes):
                    distance[i,j] = nodes[i].get_distance(nodes[j], topology_only=topology_only)+1
                    distance[j,i] = distance[i,j]
            if not topology_only:
                distance = distance - 1
            closeness_df.loc[name, feature_name] = np.amax(1/np.sum(distance, axis=1))


    return closeness_df
