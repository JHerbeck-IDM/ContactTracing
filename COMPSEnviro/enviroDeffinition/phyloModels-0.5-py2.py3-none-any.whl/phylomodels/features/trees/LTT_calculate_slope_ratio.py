import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, LTT_param

@tree_param
@LTT_param
def LTT_calculate_slope_ratio(trees, LTTs, **kwargs):
    """
    Returns the ratio of the slopes beteween the root and the maximal number of
    lineages and from the max lineages to the last leaf from the lineages
    through time plot/view of the tree.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict): The dict of trees to calculate the statistic from.
        LTTs (dict) : Optional. A dictionary with each key being one of the
                      input trees. The value is a dictionary represention of
                      the lineage through time plot.

    Returns:
        DataFrame   : Data frame containing the ratio of slope_1 and slope_2.

    """

    # Initialize output dataframe
    slope_ratio_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        times = np.array(list(LTTs[name].keys()))
        t_max_L = max(LTTs[name], key=LTTs[name].get)
        slope_1 = (LTTs[name][t_max_L]-LTTs[name][times[0]])/(t_max_L-times[0])
        slope_2 = (LTTs[name][times[-1]]-LTTs[name][t_max_L])/(times[-1]-t_max_L)
        slope_ratio_df.loc[name, 'slope_ratio'] = slope_1/slope_2

    # Finalize and return
    return  slope_ratio_df
