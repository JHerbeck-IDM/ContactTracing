import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
def top_calculate_B1(trees, attr, attr_values, **kwargs):
    """
    Return inverse sum of the maximum numder of nodes between the leaves and
    each internal node (excluding the root). If an attribute is given this is
    calculated for each unique value of the attribute among the internal nodes.
    Shao and Sokal, Systematic Zoology 39(3) p. 266-276 1990

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and buildng
                               a list of values found in them.

    Returns:
        DataFrame            : The inverse sum of the maximum number of nodes
                               between the leaves and each internal node for
                               the whole tree and if an attr is provided,
                               conditionally for each unique value of the
                               attribute.

    """

    # Initialize output dataframe
    B1_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        M          = []
        node_attrs = []
        for node in tree.iter_descendants():
            if not node.is_leaf():
                _, M_i = node.get_farthest_leaf(topology_only=True)
                # add 1 so a pretermius node is not 0, seems to be what the
                # definition intended
                M.append(M_i+1)
                node_attrs.append(getattr(node, attr)) if attr else None
        M = np.array(M)

        B1_df.loc[name, 'B1'] = np.sum(1/M)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If M[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    B1_df.loc[name, 'B1_' + attr_value] = np.sum(1/M[idx])
                else:
                    B1_df.loc[name, 'B1_' + attr_value] = 0.0

    # Finalize and return
    return B1_df
