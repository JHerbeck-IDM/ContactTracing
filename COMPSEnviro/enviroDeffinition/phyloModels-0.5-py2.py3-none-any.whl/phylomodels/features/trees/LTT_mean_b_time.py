import numpy as np
import pandas as pd

def LTT_mean_b_time(trees, **kwargs):
    """
    Returns the mean time between two consecutive up steps (mean branching 
    times) from the lineages through time plot/view of the tree.
    
    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.

    Returns:
        DataFrame                : Data frame containing the bean step up time.
                                                                  
    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Get LTT "plot"
    if 'LTTs' in kwargs:
        LTTs = kwargs['LTTs']
    else:
        from phylomodels.features.trees.helper.get_LTT import get_LTT
        LTTs = get_LTT(trees)['LTTs']

    # Initialize output dataframe
    mean_b_time_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():      
        times = np.array(list(LTTs[name].keys()))
        lin_diff = np.diff(list(LTTs[name].values()))
        lin_diff = np.append(0,lin_diff)
        step_up_times = times[lin_diff>0]
        mean_b_time_df.loc[name, 'mean_b_time'] = np.mean(np.diff(step_up_times))

    # Finalize and return
    return  mean_b_time_df
