import numpy as np
import pandas as pd

def eigen_gap(trees, **kwargs):
    """
    Return the eigen gap from the eigen spectrum of the distance laplacian 
    matrix. This can be calculated using branch lengths (default) or topology 
    (number of edges).

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of 
                                   branches) instead of branch lengths.

    Returns:
        DataFrame                : The eigen gap in the spectrum of the 
                                   distance laplacian of the whole tree.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False
    
    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that    
    if topology_only:
        feature_name = 'eigen_gap_topology'
    else:
        feature_name = 'eigen_gap'
        
    if 'eigenvalues_dist_lap' in kwargs:
        eigenvalues = kwargs['eigenvalues_dist_lap']
    elif 'eigenvalues_dist_lap_topology' in kwargs:
        eigenvalues = kwargs['eigenvalues_dist_lap_topology']
    else:
        from phylomodels.features.trees.helper.get_eigenvalues_dist_lap import get_eigenvalues_dist_lap
        eigen = get_eigenvalues_dist_lap(trees, topology_only=topology_only)
        if topology_only:
            eigenvalues = eigen['eigenvalues_dist_lap_topology']
        else:
            eigenvalues = eigen['eigenvalues_dist_lap']
		
    # Initialize output dataframe
    eigengap_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        w = eigenvalues[name]
        w.sort()
        gaps = np.diff(np.real(w))
        eigengap_df.loc[name, feature_name] = np.amax(gaps)


    return eigengap_df
