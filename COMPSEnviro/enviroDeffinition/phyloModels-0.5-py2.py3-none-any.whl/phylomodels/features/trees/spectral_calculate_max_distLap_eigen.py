import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, topology_param, distLap_eigenvalues_param

@tree_param
def spectral_calculate_max_distLap_eigen(trees, **kwargs):
    """
    Return the largest eigenvalue of the distance laplacian matrix. This can be
    calculated using branch lengths (default) or topology (number of edges).
    Chindelevitch et al bioRxiv https://doi.org/10.1101/608646

    Args:
        trees (dict)                 : The dict of trees to calculate the
                                       statistic from.
        topology_only (bool)         : Optional. If set to True (default False)
                                       calculate the height using the "topology"
                                       (number of branches) instead of branch
                                       lengths.
        eigenvalues_dist_lap (dict)  : Optional. A dictionary containing the
        eigenvalues_dist_lap_topology  eigenvalues of the distance Laplacian
                                       matrix for each tree. If the matrix was
                                       calculated with branch lengths it should
                                       be have the shorter name. If instead the
                                       matrix was calculated with the
                                       "topology" distance then the name with
                                       the topology suffix should be used.

    Returns:
        DataFrame                    : The largest eigenvalue of the distance
                                       laplacian of the whole tree.

    """

    topology_only, kwargs = topology_param(**kwargs)
    eigenvalues, kwargs   = distLap_eigenvalues_param(trees, topology_only, **kwargs)

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'eigenvalue_max_dLap_topology'
    else:
        feature_name = 'eigenvalue_max_dLap'

    # Initialize output dataframe
    eigenvalue_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        w = eigenvalues[name]
        eig = np.amax(w)
        eigenvalue_df.loc[name, feature_name] = np.real(eig)


    return eigenvalue_df
