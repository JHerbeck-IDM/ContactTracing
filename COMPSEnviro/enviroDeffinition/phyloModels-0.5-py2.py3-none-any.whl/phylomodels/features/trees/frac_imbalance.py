import numpy as np
import pandas as pd

def frac_imbalance(trees, **kwargs):
    """
    Return the fraction of internal nodes that have different numbers of leaves
    on the two sides. This summary static requires a tree to be bifurcating.
    There may be ways to handle nonbifurcating trees, but I have nto looked
    into it yet.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The fraction of internal nodes that are 
                                   imbalanced for the whole tree and if an attr
                                   is provided conditionally for each unique 
                                   value of the attribute.
    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    frac_imbalances_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs     = []
            leaf_not_equals = []
            for node in tree.traverse():
                if not node.is_leaf():
                    children = node.children
                    if len(children) != 2:
                        raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
                    # Get the attribute of the node
                    node_attrs.append(getattr(node, attr))
                    leaf_not_equals.append(len(children[0]) != len(children[1]))
            leaf_not_equals = np.array(leaf_not_equals)
            node_attrs = np.array(node_attrs)
            frac_imbalances_df.loc[name, 'frac_imbalance'] = np.mean(leaf_not_equals)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_not_equals[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    frac_imbalances_df.loc[name, 'frac_imbalance_' + attr_value] = 0.0
                else:
                    frac_imbalances_df.loc[name, 'frac_imbalance_' + attr_value] = np.mean(leaf_not_equals[attr_value==node_attrs])
        # If not using attr option we only need the branch lengths
        else:
            leaf_not_equals = []
            for node in tree.traverse():
                if not node.is_leaf():
                    children = node.children
                    if len(children) != 2:
                        raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
                    leaf_not_equals.append(len(children[0]) != len(children[1]))
            leaf_not_equals = np.array(leaf_not_equals)
            frac_imbalances_df.loc[name, 'frac_imbalance'] = np.mean(leaf_not_equals)
            
    # Finalize and return
    return frac_imbalances_df
