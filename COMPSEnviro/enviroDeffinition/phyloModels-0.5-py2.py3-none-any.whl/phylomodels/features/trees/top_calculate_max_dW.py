import pandas as pd
from collections import Counter
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
def top_calculate_max_dW(trees, **kwargs):
    """
    Return the maximum difference in width between neighboring levels.
    Colijn and Gardy Evolution, Medicine, and Public Health 2014(1) p.96-108 (2014)


    Args:
        trees (dict): The dict of trees to calculate the statistic from.

    Returns:
        DataFrame   : The maximum difference between neighboring levels.

    """

    dWs = []
    # Initialize output dataframe
    dWs_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        depths = []
        for node in tree.iter_descendants():
            depths.append( tree.get_distance(node, topology_only=True) )

        widths = Counter(depths)
        depths = sorted(list(widths.keys()))
        dW = 0
        for i in range(len(depths)-1):
            dW = max(dW, abs(widths[depths[i]]-widths[depths[i+1]]))
        dWs_df.loc[name, 'max_dW'] = dW

    # Finalize and return
    return  dWs_df
