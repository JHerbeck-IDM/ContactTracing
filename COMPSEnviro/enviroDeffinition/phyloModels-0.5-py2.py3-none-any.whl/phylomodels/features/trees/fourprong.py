import numpy as np
import pandas as pd

#TODO normalize somehow
def fourprong(trees, **kwargs):
    """
    Return the number of caterpillars (ladders) with 4 tips. If an attribute
    is given than this returns the number for each unique value of the 
    attribute in addition to all nodes. In order to be considered a ladder (per 
    attribution) has to have at least one node with the approperiate value. A 
    better definition might be the most, majority, or all of the nodes in the 
    ladder have to have that value.
    
    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : Data frame containing the number 
                                   4-caterpillars largest ladder normalized by
                                   number of leaves for the tree and if attr is
                                   provided the conditional ladder size based 
                                   on the node attribute (as different 
                                   columns). Each tree having its own row.
                                   
    """

    def is_semipreterminal(node):
        return any(child.is_leaf() for child in node.children)
    
    def is_preterminal(node):
        if len(node.children) < 1:
            return False
        return all(child.is_leaf() for child in node.children)

    def ladder_chain(root, nodes):
        nodes.remove(root)
        if(is_semipreterminal(root) and not is_preterminal(root)):
            curr_size = 1
            for child in root.children:
                curr_size += ladder_chain(child, nodes)
            return curr_size
        # The cherry at the end of the ladder
        elif is_preterminal(root):
            curr_size = 1
            return curr_size
        else:
            return 0

    def ladder_chain_ID(root, nodes):
        nodes.remove(root)
        curr_size = {}
        curr_size[getattr(root, attr)] = 1
        if(is_semipreterminal(root) and not is_preterminal(root)):
            for child in root.children:
                temp = ladder_chain_ID(child, nodes)
                curr_size = {key: curr_size.get(key,0) + temp.get(key,0) for key in set(curr_size) | set(temp)}
            return curr_size
        elif is_preterminal(root):
            return curr_size
        else:
            return {}

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    fourprongs_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        nodes = tree.get_descendants('levelorder')
        
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            nodes_temp = nodes.copy()
            fourprongs = {}
            while(nodes_temp):
                curr_size = {}
                root = nodes_temp[0]
                nodes_temp.remove(root)
                if(is_semipreterminal(root) and not is_preterminal(root)):
                    curr_size[getattr(root, attr)] = 1
                    for child in root.children:
                        temp = ladder_chain_ID(child, nodes_temp)
                        curr_size = {key: curr_size.get(key,0) + temp.get(key,0) for key in set(curr_size) | set(temp)}
                    for key in set(curr_size) - set(fourprongs):
                        fourprongs[key] = 0
                    for key in curr_size.keys():
                        fourprongs[key] += np.sum(list(curr_size.values()))==3       
                    
            keys = fourprongs.keys()
            for attr_value in attr_values:
                fourprongs_df.loc[name, 'fourprong_' + attr_value] = 0
                if attr_value in keys:
                    fourprongs_df.loc[name, 'fourprong_' + attr_value] = fourprongs[attr_value]   

        ladder_size = []
        while(nodes):
            root = nodes[0]
            nodes.remove(root)
            if(is_semipreterminal(root) and not is_preterminal(root)):
                curr_size = 1 
                for child in root.children:
                    curr_size += ladder_chain(child, nodes)
                ladder_size.append(curr_size)          
        
        if len(ladder_size) < 1:
            ladder_size.append(0)
        ladder_size = np.array(ladder_size)
        fourprongs_df.loc[name, 'fourprong'] = np.sum(ladder_size==3)

    # Finalize and return
    return fourprongs_df
