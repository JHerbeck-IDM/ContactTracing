import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, LTT_param

@tree_param
@LTT_param
def LTT_calculate_slope_1(trees, LTTs, **kwargs):
    """
    Returns the slope beteween the origin and the maximal number of lineages
    from the lineages through time plot/view of the tree.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict): The dict of trees to calculate the statistic from.
        LTTs (dict) : Optional. A dictionary with each key being one of the
                      input trees. The value is a dictionary represention of
                      the lineage through time plot.

    Returns:
        DataFrame   : Data frame containing the slope from the root to the
                      widest point of the tree (maximum number of lineages).

    """

    # Initialize output dataframe
    slope_1_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        times = np.array(list(LTTs[name].keys()))
        t_max_L = max(LTTs[name], key=LTTs[name].get)
        slope_1_df.loc[name, 'slope_1'] = (LTTs[name][t_max_L]-LTTs[name][times[0]])/(t_max_L-times[0])


    # Finalize and return
    return  slope_1_df
