import numpy as np
import pandas as pd

def min_adjacency_eigen(trees, **kwargs):
    """
    Return the minimum (positive) eigenvalue from the adjacency matrix. This 
    can be calculated using weights (default) or unweighted.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of 
                                   branches) instead of branch lengths.

    Returns:
        DataFrame                : The minimum postive eigenvalue of the 
                                   adjacency matrix for the tree.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False
    
    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that    
    if topology_only:
        feature_name = 'eigenvalue_min_adj_topology'
    else:
        feature_name = 'eigenvalue_min_adj'
        
    if 'eigenvalues_adj' in kwargs:
        eigenvalues = kwargs['eigenvalues_adj']
    elif 'eigenvalues_adj_topology' in kwargs:
        eigenvalues = kwargs['eigenvalues_adj_topology']
    else:
        from phylomodels.features.trees.helper.get_eigenvalues_adj import get_eigenvalues_adj
        eigen = get_eigenvalues_adj(trees, topology_only=topology_only)
        if topology_only:
            eigenvalues = eigen['eigenvalues_adj_topology']
        else:
            eigenvalues = eigen['eigenvalues_adj']
		
    # Initialize output dataframe
    eigenvalue_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items(): 
        w = eigenvalues[name]
        eig = np.amin(w[w>0])
        eigenvalue_df.loc[name, feature_name] = np.real(eig)

    return eigenvalue_df
