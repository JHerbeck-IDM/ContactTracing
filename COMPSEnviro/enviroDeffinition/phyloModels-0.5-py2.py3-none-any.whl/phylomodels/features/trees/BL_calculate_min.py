import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
def BL_calculate_min(trees, attr, attr_values, **kwargs):
    """
    Return the minimum branch length of a tree or dict of trees. If an attribute
    is provided, this statistic is calculated for all branch lengths and
    condtionally for each unique value of the attribute.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and building
                               a list of values found in them.

    Returns:
        DataFrame            : Data frame containing the minimum branch length
                               of the tree(s), and if attr is provided, the
                               conditional mean based on the node attribute (as
                               different columns).
    """

    # Initialize output dataframe
    min_BLs_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        branch_lengths = []
        node_attrs     = []
        for node in tree.iter_descendants():
            branch_lengths.append(node.dist)
            node_attrs.append(getattr(node.up, attr)) if attr else None
        branch_lengths = np.array(branch_lengths)

        min_BLs_df.loc[name, 'min_branch_length'] = np.amin(branch_lengths)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If branch_lengths[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    min_BLs_df.loc[name, 'min_branch_length_' + attr_value] = np.amin(branch_lengths[idx])
                else:
                    min_BLs_df.loc[name, 'min_branch_length_' + attr_value] = 0.0

    # Finalize and return
    return min_BLs_df
