import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, topology_param

@tree_param
@attr_param
def tree_height_calculate_max(trees, attr, attr_values, **kwargs):
    """
    Return the maximum distance between the root and tips. This can be
    calculated using branch lengths (default) or topology (number of nodes).
    Additionally it can be calculated for the whole tree or conditionally based
    on the attribute values of attr of the leaf nodes
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the tree height
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and buildng
                               a list of values found in them.
        topology_only (bool) : Optional. If set to True (default False)
                               calculate the height using the "topology"
                               (number of branches) instead of branch lengths.

    Returns:
        DataFrame            : The distance from the root to the farthest leaf.
    """

    topology_only, kwargs = topology_param(**kwargs)

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'max_height_topology'
    else:
        feature_name = 'max_height'

    # Initialize output dataframe
    max_heights_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        heights    = []
        node_attrs = []
        for node in tree.iter_leaves():
            heights.append( tree.get_distance(node, topology_only=topology_only) )
            node_attrs.append(getattr(node, attr)) if attr else None
        heights = np.array(heights)
        max_heights_df.loc[name, feature_name] = np.max(heights)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If branch_lengths[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    max_heights_df.loc[name, feature_name + '_' + attr_value] = np.max(heights[idx])
                else:
                    max_heights_df.loc[name, feature_name + '_' + attr_value] = 0.0

    # Finalize and return
    return max_heights_df
