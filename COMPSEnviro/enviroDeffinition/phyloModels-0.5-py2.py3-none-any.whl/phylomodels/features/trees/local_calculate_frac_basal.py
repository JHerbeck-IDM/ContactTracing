import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, threshold_param

@tree_param
@attr_param
def local_calculate_frac_basal(trees, attr, attr_values, **kwargs):
    '''
    Return the fraction of leaves that are basal (probably parents of other
    nodes) versus terminal (ends of transmission chains).
    I may have over simplified this some. I am just checking for a short branch
    length not doing anything to make sure there really are down stream leaves.
    Moncla et al eLife 10 p.e66448 (2021)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and building
                               a list of values found in them.
        threshold (float)    : Optional. Minimum branch length to collapse.

    Returns:
        DataFrame            : The maximum eigenvalue of the adjacency matrix
                               for the tree.

    '''

    threshold, kwargs = threshold_param(**kwargs)

    # Initialize output dataframe
    frac_basal_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        basal      = []
        node_attrs = []
        for node in tree.traverse("levelorder"):
            basal.append(node.dist<=threshold)
            node_attrs.append(getattr(node, attr, "None")) if attr else None
        basal = np.array(basal)

        frac_basal_df.loc[name, 'frac_basal'] = np.sum(basal)/len(basal)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If basal[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    frac_basal_df.loc[name, 'frac_basal_' + attr_value] = np.sum(basal[idx])/np.sum(idx)
                else:
                    frac_basal_df.loc[name, 'frac_basal_' + attr_value] = 0.0

    return frac_basal_df
