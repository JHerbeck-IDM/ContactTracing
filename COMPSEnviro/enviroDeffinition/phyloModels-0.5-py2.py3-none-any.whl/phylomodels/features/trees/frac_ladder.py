import numpy as np
import pandas as pd

def frac_ladder(trees, **kwargs):
    """
    Return the fraction of internal nodes in a ladders. If an attribute is 
    suppled this fraction is also calculated conditionally for each value of 
    the attribute
    
    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : Data frame containing the fraction of 
                                   internal nodes that are in ladders for the 
                                   tree and if attr is provided the conditional
                                   fraction of nodes in ladders based on the 
                                   node attribute (as different columns). Each
                                   tree having its own row.
                                   
    """

    def is_semipreterminal(node):
        return any(child.is_leaf() for child in node.children)
    
    def is_preterminal(node):
        return all(child.is_leaf() for child in node.children)
    
    
    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    frac_ladders_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            ladder     = []
            node_attrs = []
            for node in tree.traverse('levelorder'):
                if not node.is_leaf():
                    if(is_semipreterminal(node) and not is_preterminal(node)):
                        ladder.append(True)
                    else:
                        ladder.append(False)
                    node_attrs.append(getattr(node, attr))
            ladder = np.array(ladder)
            node_attrs = np.array(node_attrs)
            frac_ladders_df.loc[name, 'frac_ladder'] = np.sum(ladder)/len(ladder)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_not_equals[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    frac_ladders_df.loc[name, 'frac_ladder_' + attr_value] = 0.0
                else:
                    frac_ladders_df.loc[name, 'frac_ladder_' + attr_value] = np.sum(ladder[attr_value==node_attrs])/np.sum([attr_value==node_attrs])
        # If not using attr option we only need the branch lengths
        else:
            ladder     = []
            for node in tree.traverse('levelorder'):
                if not node.is_leaf():
                    if(is_semipreterminal(node) and not is_preterminal(node)):
                        ladder.append(True)
                    else:
                        ladder.append(False)
            frac_ladders_df.loc[name, 'frac_ladder'] = np.sum(ladder)/len(ladder)
            
    # Finalize and return
    return frac_ladders_df
