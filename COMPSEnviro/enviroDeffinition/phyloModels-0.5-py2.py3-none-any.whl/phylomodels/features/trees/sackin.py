import numpy as np
import pandas as pd

def sackin(trees, **kwargs):
    """
    Return sum of the numder of nodes between the leaves and root. If an
    attribute is given this is calucaled for each unique value of the attribute
    among the leaf nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The sum of the number of nodes between the 
                                   leaves and the root for the whole tree and 
                                   if an attr is provided, conditionally for 
                                   each unique value of the attribute.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    sackins_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs = []
            sackin     = []
            for node in tree.iter_leaves():
                node_attrs.append(getattr(node, attr))
                sackin.append(tree.get_distance(node, topology_only=True))
            sackin = np.array(sackin)
            node_attrs = np.array(node_attrs)
            sackins_df.loc[name, 'sackin'] = np.sum(sackin)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If sackin[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    sackins_df.loc[name, 'sackin_' + attr_value] = 0.0
                else:
                    sackins_df.loc[name, 'sackin_' + attr_value] = np.sum(sackin[idx])
        # If not using attr option we only need the branch lengths
        else:
            sackin = []
            for node in tree.iter_leaves():
                sackin.append(tree.get_distance(node, topology_only=True))
            sackin = np.array(sackin)
            sackins_df.loc[name, 'sackin'] = np.sum(sackin)
            
    # Finalize and return
    return sackins_df
