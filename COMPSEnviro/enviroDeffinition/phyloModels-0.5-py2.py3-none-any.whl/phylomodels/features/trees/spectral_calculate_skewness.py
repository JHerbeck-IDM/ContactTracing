import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, topology_param, distLap_eigenvalues_param

@tree_param
def spectral_calculate_skewness(trees, **kwargs):
    """
    Return the skewness of the eigen spectrum of the distance laplacian
    matrix. This can be calculated using branch lengths (default) or topology
    (number of edges).
    Chindelevitch et al bioRxiv https://doi.org/10.1101/608646

    Args:
        trees (dict)                 : The dict of trees to calculate the
                                       statistic from.
        topology_only (bool)         : Optional. If set to True (default False)
                                       calculate the height using the "topology"
                                       (number of branches) instead of branch
                                       lengths.
        eigenvalues_dist_lap (dict)  : Optional. A dictionary containing the
        eigenvalues_dist_lap_topology  eigenvalues of the distance Laplacian
                                       matrix for each tree. If the matrix was
                                       calculated with branch lengths it should
                                       be have the shorter name. If instead the
                                       matrix was calculated with the
                                       "topology" distance then the name with
                                       the topology suffix should be used.

    Returns:
        DataFrame                    : The skewness of the spectrum of the
                                       distance laplacian of the whole tree.

    """

    topology_only, kwargs = topology_param(**kwargs)
    eigenvalues, kwargs   = distLap_eigenvalues_param(trees, topology_only, **kwargs)

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'skewness_topology'
    else:
        feature_name = 'skewness'

    # Initialize output dataframe
    skewness_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        w = eigenvalues[name]
        num_nodes = len(w)
        mu = np.mean(w)
        skewness = ( np.sum((w-mu)**3)/num_nodes ) / ( np.sum((w-mu)**2)/num_nodes )**(3/2)
        skewness_df.loc[name, feature_name] = skewness


    return skewness_df
