import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, normalize_param
from phylomodels.features.trees.helper.get_node_properties import is_preterminal

@tree_param
@attr_param
#TODO normalize somehow
def smallConfig_calculate_double_cherries(trees, attr, attr_values, **kwargs):
    """
    Return the number of nodes with two cherries as children. Currently, we
    are not checking if the tree is bifurcating so we are really checking for
    internal nodes with all children being cherries. If an attribute is
    supplied this fraction is also calculated conditionally for each value of
    the attribute.
    Chindelevitch et al bioRxiv https://doi.org/10.1101/608646

    Args:
        trees (dict)          : The dict of trees to calculate the statistic
                                from.
        attr (str)            : Optional. The name of the attribute to use in
                                conditionally calculating the statistic.
        attr_values (ndarray) : Optional. List of the unique values that attr
                                could take (or at least the ones we are
                                interested) in. If not provided it will be
                                calculated by looping over all trees and
                                building a list of values found in them.
        normalize_param (bool): Optional. Whether or not to normalize the
                                statistics.

    Returns:
        DataFrame             : Data frame containing the number of nodes are
                                parents to cherries for the tree and if attr is
                                provided the conditional fraction of nodes in
                                cherry_arrays based on the node attribute (as
                                different columns). Each tree having its own
                                row.

    """

    # Process optional arguements
    normalize, kwargs = normalize_param(**kwargs)

    # Initialize output dataframe
    cherries_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        cherry_array     = []
        node_attrs   = []
        for node in tree.traverse('levelorder'):
            if not node.is_leaf():
                if all(is_preterminal(child) for child in node.children):
                    cherry_array.append(True)
                else:
                    cherry_array.append(False)
                node_attrs.append(getattr(node, attr, "None")) if attr else None
        cherry_array = np.array(cherry_array)

        if normalize:
            cherries_df.loc[name, 'double_cherries'] = np.sum(cherry_array)/len(cherry_array)
        else:
            cherries_df.loc[name, 'double_cherries'] = np.sum(cherry_array)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                if normalize:
                   # If cherry_array[idx] returns an empty array the numpy functions will fail
                   if np.any(idx):
                       cherries_df.loc[name, 'double_cherries_' + attr_value] = np.sum(cherry_array[idx])/np.sum(idx)
                   else:
                       cherries_df.loc[name, 'double_cherries_' + attr_value] = 0.0
                else:
                   # If cherry_array[idx] returns an empty array the numpy functions will fail
                   if np.any(idx):
                       cherries_df.loc[name, 'double_cherries_' + attr_value] = np.sum(cherry_array[idx])
                   else:
                       cherries_df.loc[name, 'double_cherries_' + attr_value] = 0.0

    # Finalize and return
    return cherries_df
