import numpy as np
import pandas as pd

def kurtosis(trees, **kwargs):
    """
    Return the kurtosis of the eigen spectrum of the distance laplacian 
    matrix. This can be calculated using branch lengths (default) or topology 
    (number of edges).

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of 
                                   branches) instead of branch lengths.

    Returns:
        DataFrame                : The kurtosis of the spectrum of the 
                                   distance laplacian of the whole tree.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False
    
    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that    
    if topology_only:
        feature_name = 'kurtosis_topology'
    else:
        feature_name = 'kurtosis'
        
    if 'eigenvalues_dist_lap' in kwargs:
        eigenvalues = kwargs['eigenvalues_dist_lap']
    elif 'eigenvalues_dist_lap_topology' in kwargs:
        eigenvalues = kwargs['eigenvalues_dist_lap_topology']
    else:
        from phylomodels.features.trees.helper.get_eigenvalues_dist_lap import get_eigenvalues_dist_lap
        eigen = get_eigenvalues_dist_lap(trees, topology_only=topology_only)
        if topology_only:
            eigenvalues = eigen['eigenvalues_dist_lap_topology']
        else:
            eigenvalues = eigen['eigenvalues_dist_lap']
		
    # Initialize output dataframe
    kurtosis_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        w = eigenvalues[name]
        num_nodes = len(w)
        mu = np.mean(w)
        kurtosis = ( np.sum((w-mu)**4)/num_nodes ) / ( np.sum((w-mu)**2)/num_nodes )**2
        kurtosis_df.loc[name, feature_name] = kurtosis


    return kurtosis_df
