import numpy as np
import pandas as pd

def eigen_centrality_max(trees, **kwargs):
    """
    Return the maximum value from the Perron-Frobenius eignevector of the
    adjacency matrix. This can be calculated using weights (default) or
    unweighted. Additionally it can be calculated for the whole tree or 
    conditionally based on the attribute values of attr of the nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the tree height
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of 
                                   branches) instead of branch lengths.

    Returns:
        DataFrame                : The maximum value from the Perron-Frobenius
                                   eigenvector of the adjacency metrix for the
                                   whole tree and if an attr is provided, 
                                   conditionally for each unique value of the 
                                   attribute.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False
    
    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that    
    if topology_only:
        feature_name = 'eigenvector_max_unweighted'
    else:
        feature_name = 'eigenvector_max'
		
    # Initialize output dataframe
    eigenvector_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        nodes = [tree] + tree.get_descendants('levelorder')
        num_nodes = len(nodes)
        nodes = {node: i for i, node in enumerate(nodes)}
        adjacency = np.zeros((num_nodes, num_nodes)) 
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs = []
            if topology_only:
                for node, i in nodes.items():
                    node_attrs.append(getattr(node, attr))
                    for child in node.children:
                        adjacency[i, nodes[child]] = 1
                        adjacency[nodes[child], i] = 1
            else:
                for node, i in nodes.items():
                    node_attrs.append(getattr(node, attr))
                    for child in node.children:
                        adjacency[i, nodes[child]] = child.dist
                        adjacency[nodes[child], i] = child.dist
            w, v = np.linalg.eig(adjacency)
            idx = np.argmax(w)
            eigenvector = v[:,idx]
            eigenvector = eigenvector/np.linalg.norm(eigenvector)
            eigenvector_df.loc[name, feature_name] = np.real(np.amax(np.abs(eigenvector)))
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If no attr_value in node_attrs
                if np.sum(idx) == 0:
                    eigenvector_df.loc[name, feature_name + '_' + attr_value] = 0
                else:
                    eigenvector_df.loc[name, feature_name + '_' + attr_value] = np.real(np.amax(np.abs(eigenvector[idx])))
        else:
            if topology_only:
                for node, i in nodes.items():
                    for child in node.children:
                        adjacency[i, nodes[child]] = 1
                        adjacency[nodes[child], i] = 1
            else:
                for node, i in nodes.items():
                    for child in node.children:
                        adjacency[i, nodes[child]] = child.dist
                        adjacency[nodes[child], i] = child.dist
            w, v = np.linalg.eigh(adjacency)
            idx = np.argmax(w)
            eigenvector = v[:,idx]
            eigenvector = eigenvector/np.linalg.norm(eigenvector)
            eigenvector_df.loc[name, feature_name] = np.real(np.amax(np.abs(eigenvector)))


    return eigenvector_df
