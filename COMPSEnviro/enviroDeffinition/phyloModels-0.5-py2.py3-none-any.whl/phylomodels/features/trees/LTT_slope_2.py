import numpy as np
import pandas as pd

def LTT_slope_2(trees, **kwargs):
    """
    Returns the slope beteween the maximal number of lineages and the last leaf
    from the lineages through time plot/view of the tree.
    
    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.

    Returns:
        DataFrame                : Data frame containing the slope from the
                                   the widest point of the tree (maximum number
                                   of lineages) to the last leaf.
                                                                  
    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Get LTT "plot"
    if 'LTTs' in kwargs:
        LTTs = kwargs['LTTs']
    else:
        from phylomodels.features.trees.helper.get_LTT import get_LTT
        LTTs = get_LTT(trees)['LTTs']

    # Initialize output dataframe
    slope_2_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():      
        times = np.array(list(LTTs[name].keys()))
        t_max_L = max(LTTs[name], key=LTTs[name].get)
        slope_2_df.loc[name, 'slope_2'] = (LTTs[name][times[-1]]-LTTs[name][t_max_L])/(times[-1]-t_max_L)

    # Finalize and return
    return  slope_2_df
