import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.get_distance_mat import get_distance_mat

def mean_NN_distance(trees, **kwargs):
    """
    Return the mean distance between neigboring tips. This can be calculated
    using branch lengths (default) or topology (number of nodes). Additionally
    it can be calculated for the whole tree or conditionally based on the
    attribute values of attr of the nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in
                                   conditionally calculating the tree height
        attr_values (ndarray)    : List of the unique values that attr could
                                   take (or at least the ones we are
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and
                                   buildng a list of values found in them.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of
                                   branches) instead of branch lengths.

    Returns:
        DataFrame                : The mean distance between neighboring leaves

    """

    def walk_up (tips, curnode, pathlen, topology_only=False):
        """
        Recursive function for traversing up a tree.
        """
        if topology_only:
            pathlen += 1
            if curnode.is_leaf():
                tips.append( (curnode.name, pathlen) )
            else:
                for c in curnode.children:
                    tips = walk_up(tips, c, pathlen, topology_only)
        else:
            pathlen += curnode.dist
            if curnode.is_leaf():
                tips.append( (curnode.name, pathlen) )
            else:
                for c in curnode.children:
                    tips = walk_up(tips, c, pathlen, topology_only)

        return tips


    def walk_trunk (curnode, parents, topology_only=False):
        """
        Find all tips in the tree that are within a threshold distance
        of a reference tip.
        """

        tips = []
        if topology_only:
            # first go down to parent and up other branch
            pathlen = 1
            p = parents[curnode]

            for c in p.children:
                if c == curnode: continue
                if c.is_leaf():
                    tips.append( (c.name, pathlen+1) )
                else:
                    tips.extend(walk_up([], c, pathlen, topology_only))

            # next walk down trunk until hit root
            while p in parents:
                curnode = p
                pathlen += 1
                p = parents[curnode]
                for c in p.children:
                    if c == curnode:
                        continue
                    if c.is_leaf():
                        tips.append( (c.name, pathlen+1) )
                    else:
                        tips.extend(walk_up([], c, pathlen, topology_only))
        else:
            # first go down to parent and up other branch
            pathlen = curnode.dist
            p = parents[curnode]

            for c in p.children:
                if c == curnode: continue
                if c.is_leaf():
                    tips.append( (c.name, pathlen+c.dist) )
                else:
                    tips.extend(walk_up([], c, pathlen, topology_only))

            # next walk down trunk until hit root
            while p in parents:
                curnode = p
                pathlen += p.dist
                p = parents[curnode]
                for c in p.children:
                    if c == curnode:
                        continue
                    if c.is_leaf():
                        tips.append( (c.name, pathlen+c.dist) )
                    else:
                        tips.extend(walk_up([], c, pathlen, topology_only))
        return tips

    def find_short_edges(tree, attr=None, topology_only=False):
        """
        Find the shortest edge from the earliest sequence of a patient to a
        any sequence from any other patient.
        minimize = keep only edge from earliest seq to the closest other seq
        keep_ties = [to be used in conjunction with minimize]
                    report all edges with the same minimum distance
        """

        # generate dictionary of child->parent associations
        parents = {}
        for clade in tree.traverse('levelorder'):
            for child in clade.children:
                parents.update({child: clade})

        tips = tree.get_leaves()
        num_tips = len(tips)
        distance = np.ones((num_tips, num_tips), dtype=np.float32)*float('inf')
        index = {}
        count = 0
        node_attrs = []
        if attr:
            for tip in tips:
                index.update({tip.name: count})
                # Get the attribute of the node
                node_attrs.append(getattr(tip, attr, "None"))
                count += 1
        else:
            for tip in tips:
                index.update({tip.name: count})
                count += 1


        # res = {}
        for tip1 in tips:
            # find the shortest distance in sequences that "cluster" with this one
            tip2 = []
            for tipname, dist in walk_trunk(tip1, parents, topology_only):
                tip2.append([tipname, dist])

            # t1 = tip1.name
            for t2, dist in tip2:
                i = index[tip1.name]
                j = index[t2]
                distance[i, j] = dist
                distance[j, i] = dist

        return distance, node_attrs

    # Check if we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}

    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None

    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'mean_NN_dist_topology'
        dist_name    = 'distance_mat_topology'
    else:
        feature_name = 'mean_NN_dist'
        dist_name    = 'distance_mat'

    # Initialize output dataframe
    mean_dist_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    dist_mats = get_distance_mat(trees, topology_only=topology_only)
    for name, tree in trees.items():
        #distance, node_attrs = find_short_edges(tree, attr, topology_only=topology_only)
        node_attrs = []
        idx = []
        for node in tree.traverse('levelorder'):
            if node.is_leaf():
                idx.append(True)
                node_attrs.append(getattr(node, attr, 'None')) if attr else None
            else:
                idx.append(False)
        distance = dist_mats[dist_name][name]
        distance = distance[idx,:][:,idx]
        np.fill_diagonal(distance, float('inf'))
        # If using attr option get list of values alongside the branch length
        # for conditional calculations
        if attr:
            node_attrs = np.array(node_attrs)
            mean_dist_df.loc[name, feature_name] = np.mean(np.amin(distance, axis=1))
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If no attr_value in node_attrs
                if np.sum(idx) == 0:
                    mean_dist_df.loc[name, feature_name + '_' + attr_value] = float('inf')
                else:
                    mean_dist_df.loc[name, feature_name + '_' + attr_value] = np.mean(np.amin(distance[idx,:][:,idx], axis=1))
        else:
            mean_dist_df.loc[name, feature_name] = np.mean(np.amin(distance, axis=1))


    return mean_dist_df
