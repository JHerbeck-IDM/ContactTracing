import numpy as np
import pandas as pd

#TODO add ability to calculate it over different time intervals
def branch_length_min_ratio(trees, **kwargs):
    """
    Return the ratio of the minimum internal branch length over the minimum 
    external branch length of a tree or dict of trees. If an attribute is 
    provided, this statistic is calculated for all internal/external branch
    lengths and condtionally for each unique value of the attribute.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : Data frame containing the ratio of the 
                                   minimum internal branch length and mimimum
                                   external branch length of the tree(s), and 
                                   if attr is provided, the conditional ratio
                                   based on the node attribute (as different 
                                   columns).
    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    min_BL_ratios_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            in_node_attrs     = []
            in_branch_lengths = []
            ex_node_attrs     = []
            ex_branch_lengths = []
            for node in tree.iter_descendants():
                if node.is_leaf():
                    # Get the attribute of the parent node
                    ex_node_attrs.append(getattr(node.up, attr))
                    ex_branch_lengths.append(node.dist)
                else:
                    # Get the attribute of the parent node
                    in_node_attrs.append(getattr(node.up, attr))
                    in_branch_lengths.append(node.dist)
            in_branch_lengths = np.array(in_branch_lengths)
            in_node_attrs = np.array(in_node_attrs)
            ex_branch_lengths = np.array(ex_branch_lengths)
            ex_node_attrs = np.array(ex_node_attrs)
            in_min = np.amin(in_branch_lengths)
            ex_min = np.amin(ex_branch_lengths)
            if ex_min==0 and in_min==0:
                    min_BL_ratios_df.loc[name, 'min_ratio_branch_length'] = 1.0
            elif ex_min==0:
                min_BL_ratios_df.loc[name, 'min_ratio_branch_length'] = float('inf')
            else:
                min_BL_ratios_df.loc[name, 'min_ratio_branch_length'] = in_min/ex_min
            for attr_value in attr_values:
                idx = attr_value==in_node_attrs
                idx1 = attr_value==ex_node_attrs
                # If branch_lengths[idx] returns an empty array the numpy functions will fail
                if np.sum(idx)==0 and np.sum(idx1)==0:
                    min_BL_ratios_df.loc[name, 'min_ratio_branch_length_' + attr_value] = 1.0
                elif np.sum(idx1)==0:
                    min_BL_ratios_df.loc[name, 'min_ratio_branch_length_' + attr_value] = float('inf')
                elif np.sum(idx)==0:
                    min_BL_ratios_df.loc[name, 'min_ratio_branch_length_' + attr_value] = 0.0
                else:
                    in_min_attr = np.amin(in_branch_lengths[idx])
                    ex_min_attr = np.amin(ex_branch_lengths[idx1])
                    if ex_min_attr==0 and in_min_attr==0:
                        min_BL_ratios_df.loc[name, 'min_ratio_branch_length_' + attr_value] = 1.0
                    elif ex_min_attr==0:
                        min_BL_ratios_df.loc[name, 'min_ratio_branch_length_' + attr_value] = float('inf')
                    else:
                        min_BL_ratios_df.loc[name, 'min_ratio_branch_length_' + attr_value] = in_min_attr/ex_min_attr
        # If not using attr option we only need the branch lengths
        else:
            in_branch_lengths = []
            ex_branch_lengths = []
            for node in tree.iter_descendants():
                if node.is_leaf():
                    ex_branch_lengths.append(node.dist)
                else:
                    in_branch_lengths.append(node.dist)
            in_min = np.amin(in_branch_lengths)
            ex_min = np.amin(ex_branch_lengths)
            if ex_min==0 and in_min==0:
                    min_BL_ratios_df.loc[name, 'min_ratio_branch_length'] = 1.0
            elif ex_min==0:
                min_BL_ratios_df.loc[name, 'min_ratio_branch_length'] = float('inf')
            else:
                min_BL_ratios_df.loc[name, 'min_ratio_branch_length'] = in_min/ex_min
         
    # Finalize and return
    return min_BL_ratios_df
