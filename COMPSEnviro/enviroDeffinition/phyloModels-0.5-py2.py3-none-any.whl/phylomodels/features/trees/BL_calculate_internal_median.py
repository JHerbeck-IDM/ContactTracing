import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
#TODO look at allowing this to be broken up over time periods
def BL_calculate_internal_median(trees, attr, attr_values, **kwargs):
    """
    Return the median of the internal branch lengths. If an attribute is
    provided these statistics are calculated for all internal branch lengths
    and condtionally for each unique value of the attribute.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and
                               building a list of values found in them.

    Returns:
        DataFrame            : Data frame containing the median internal branch
                               length for the tree and if attr is provided the
                               conditional median based on the node attribute
                               (as different columns). Each tree having its own row.
    """

    # Initialize output dataframe
    median_BLs_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        branch_lengths = []
        node_attrs     = []
        for node in tree.iter_descendants():
            if not node.is_leaf():
                # Get the attribute of the parent node
                branch_lengths.append(node.dist)
                node_attrs.append(getattr(node.up, attr)) if attr else None
        branch_lengths = np.array(branch_lengths)

        median_BLs_df.loc[name, 'median_in_branch_length'] = np.median(branch_lengths)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If branch_lengths[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    median_BLs_df.loc[name, 'median_in_branch_length_' + attr_value] = np.median(branch_lengths[idx])
                else:
                    median_BLs_df.loc[name, 'median_in_branch_length_' + attr_value] = 0.0

    # Finalize and return
    return median_BLs_df
