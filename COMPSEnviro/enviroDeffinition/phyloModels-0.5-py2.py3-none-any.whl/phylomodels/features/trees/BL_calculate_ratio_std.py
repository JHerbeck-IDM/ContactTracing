from numpy import std
from phylomodels.features.trees.helper.calculate_branch_length_metrics import calculate_branch_length_metrics

#TODO add ability to calculate it over different time intervals
def BL_calculate_ratio_std(trees, **kwargs):
    """
    Return the ratio of the standard deviation of internal branch lengths over
    the standard deviation of external branch length of a tree or dict of
    trees. If an attribute is provided, this statistic is calculated for all
    internal/external branch lengths and condtionally for each unique value of
    the attribute.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and building
                               a list of values found in them.

    Returns:
        DataFrame            : Data frame containing the ratio of the standard
                               deviation of internal branch lengths and standard
                               deviation of external branch lengths of the
                               tree(s), and if attr is provided, the conditional
                               ratio based on the node attribute (as different
                               columns).

    """

    # Initialize output dataframe
    std_BLs_df = calculate_branch_length_metrics(trees, functions_dict={'std': std}, branch_type='ratio', **kwargs)

    # Finalize and return
    return std_BLs_df
