import pandas as pd

def cluster_max(trees, **kwargs):
    """
    Return the maximum cluster size, where a cluster is defined as a connected
    group of nodes with the same value for an attribute. If no attribute is 
    given the function will determine that all nodes belong to the same group
    and return the number of nodes (instead of throwing an error).

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The maximum cluster size for each value of 
                                   the provided attribute.

    """

    def match_descendents(root, nodes):
        nodes.remove(root)
        cluster_size = 1
        for child in root.children:
            if( getattr(root, attr)==getattr(child, attr)):
                cluster_size += match_descendents(child, nodes)
        return cluster_size
    
    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    cluster_max_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        if attr:
            clusters = {}
            nodes = list(tree.traverse("levelorder"))
            cluster_max_df.loc[name, 'cluster_max'] = 0
            for attr_value in attr_values:
                clusters[attr_value] = []
        
            while(nodes):
                root = nodes[0]
                nodes.remove(root)
                cluster_size = 1
                for child in root.children:
                    if(getattr(root, attr)==getattr(child, attr)):
                        cluster_size += match_descendents(child, nodes)
                clusters[getattr(root, attr)].append(cluster_size)
            
            for key, cluster in clusters.items():
                if len(cluster)<1:
                    cluster_max_df.loc[name, 'cluster_max_' + key] = 0
                else:
                    cluster_max_df.loc[name, 'cluster_max_' + key] = max(cluster)
                cluster_max_df.loc[name, 'cluster_max'] = max(cluster_max_df.loc[name, 'cluster_max'],
                                                              cluster_max_df.loc[name, 'cluster_max_' + key])
        else:
            cluster_max_df.loc[name, 'cluster_max'] = len(list(tree.traverse('levelorder')))
            
    return cluster_max_df
