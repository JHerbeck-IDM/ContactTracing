import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, LTT_param

@tree_param
@LTT_param
def LTT_calculate_slope_2(trees, LTTs, **kwargs):
    """
    Returns the slope beteween the maximal number of lineages and the last leaf
    from the lineages through time plot/view of the tree.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict): The dict of trees to calculate the statistic from.
        LTTs (dict) : Optional. A dictionary with each key being one of the
                      input trees. The value is a dictionary represention of
                      the lineage through time plot.

    Returns:
        DataFrame   : Data frame containing the slope from the widest point of
                      the tree (maximum number of lineages) to the last leaf.

    """

    # Initialize output dataframe
    slope_2_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        times = np.array(list(LTTs[name].keys()))
        t_max_L = max(LTTs[name], key=LTTs[name].get)
        slope_2_df.loc[name, 'slope_2'] = (LTTs[name][times[-1]]-LTTs[name][t_max_L])/(times[-1]-t_max_L)

    # Finalize and return
    return  slope_2_df
