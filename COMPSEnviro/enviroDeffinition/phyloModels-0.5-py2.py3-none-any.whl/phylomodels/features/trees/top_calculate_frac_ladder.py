import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param
from phylomodels.features.trees.helper.get_node_properties import is_semipreterminal, is_preterminal

@tree_param
@attr_param
def top_calculate_frac_ladder(trees, attr, attr_values, **kwargs):
    """
    Return the fraction of internal nodes in a ladders. If an attribute is
    suppled this fraction is also calculated conditionally for each value of
    the attribute.
    Colijn and Gardy Evolution, Medicine, and Public Health 2014(1) p.96-108 (2014)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and buildng
                               a list of values found in them.

    Returns:
        DataFrame            : Data frame containing the fraction of internal
                               nodes that are in ladders for the tree and if
                               attr is provided the conditional fraction of
                               nodes in ladders based on the node attribute (as
                               different columns). Each tree having its own row.

    """

    # Initialize output dataframe
    frac_ladders_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        ladder     = []
        node_attrs = []
        for node in tree.traverse('levelorder'):
            if not node.is_leaf():
                if(is_semipreterminal(node) and not is_preterminal(node)):
                    ladder.append(True)
                else:
                    ladder.append(False)
                node_attrs.append(getattr(node, attr, "None")) if attr else None
        ladder = np.array(ladder)

        frac_ladders_df.loc[name, 'frac_ladder'] = np.sum(ladder)/len(ladder)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_not_equals[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    frac_ladders_df.loc[name, 'frac_ladder_' + attr_value] = np.sum(ladder[attr_value==node_attrs])/np.sum([attr_value==node_attrs])
                else:
                    frac_ladders_df.loc[name, 'frac_ladder_' + attr_value] = 0.0

    # Finalize and return
    return frac_ladders_df
