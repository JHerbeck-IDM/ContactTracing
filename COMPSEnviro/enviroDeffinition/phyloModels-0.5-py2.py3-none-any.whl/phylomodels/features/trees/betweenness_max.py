import numpy as np
import pandas as pd

#TODO normalize?
def betweenness_max(trees, **kwargs):
    """
    Return maximum betweenness of the nodes. If an attribute is given this is 
    calucaled for each unique value of the attribute among the leaf nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The maximum betweenness of the nodes for the
                                   whole tree and if an attr is provided, 
                                   conditionally for each unique value of the 
                                   attribute.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    betweenness_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # get nodes in reverse levelorder
        nodes = list(reversed([tree] + tree.get_descendants('levelorder')))
        N = len(nodes)
        clade_sizes = {}
        for node in nodes:
            sizes = []
            for child in node.children:
                sizes.append(sum(clade_sizes[child][:-1])+1)
            sizes.append(N - np.sum(sizes) - 1)
            clade_sizes[node] = sizes
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs  = []
            betweenness = []
            for node in nodes:
                node_attrs.append(getattr(node, attr))
                sizes = clade_sizes[node]
                total = 0
                for i in range(len(sizes)):
                    for j in range(i+1, len(sizes)):
                        total += sizes[i]*sizes[j]
                betweenness.append(total)
            node_attrs = np.array(node_attrs)
            betweenness = np.array(betweenness)
            betweenness_df.loc[name, 'betweenness_max'] = np.amax(betweenness)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If betweenness[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    betweenness_df.loc[name, 'betweenness_max_' + attr_value] = 0.0
                else:
                    betweenness_df.loc[name, 'betweenness_max_' + attr_value] = np.amax(betweenness[idx])
        # If not using attr option we only need the branch lengths
        else:
            betweenness = []
            for node in nodes:
                sizes = clade_sizes[node]
                total = 0
                for i in range(len(sizes)):
                    for j in range(i+1, len(sizes)):
                        total += sizes[i]*sizes[j]
                betweenness.append(total)
            betweenness_df.loc[name, 'betweenness_max'] = np.amax(betweenness)
            
    # Finalize and return
    return betweenness_df
