import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
def top_calculate_sackin_var(trees, attr, attr_values, **kwargs):
    """
    Return variance in the number of nodes between the leaves and root. If an
    attribute is given this is calculated for each unique value of the attribute
    among the leaf nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could
                                   take (or at least the ones we are
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The varience in the number of nodes between
                                   the leaves and the root for the whole tree
                                   and if an attr is provided, conditionally
                                   for each unique value of the attribute.

    """

    # Initialize output dataframe
    sackin_vars_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        sackin_var = []
        node_attrs = []
        for node in tree.iter_leaves():
            sackin_var.append(tree.get_distance(node, topology_only=True))
            node_attrs.append(getattr(node, attr)) if attr else None
        sackin_var = np.array(sackin_var)

        sackin_vars_df.loc[name, 'sackin_var'] = np.var(sackin_var)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If sackin_var[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    sackin_vars_df.loc[name, 'sackin_var_' + attr_value] = np.var(sackin_var[attr_value==node_attrs])
                else:
                    sackin_vars_df.loc[name, 'sackin_var_' + attr_value] = 0.0

    # Finalize and return
    return sackin_vars_df
