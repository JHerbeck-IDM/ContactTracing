import numpy as np
import pandas as pd

def max_dist_lap_eigen(trees, **kwargs):
    """
    Return the largest eigenvalue of the distance laplacian matrix. This can be
    calculated using branch lengths (default) or topology (number of edges).

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of 
                                   branches) instead of branch lengths.

    Returns:
        DataFrame                : The largest eigenvalue of the distance 
                                   laplacian of the whole tree.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False
    
    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that    
    if topology_only:
        feature_name = 'eigenvalue_max_dLap_topology'
    else:
        feature_name = 'eigenvalue_max_dLap'
        
    if 'eigenvalues_dist_lap' in kwargs:
        eigenvalues = kwargs['eigenvalues_dist_lap']
    elif 'eigenvalues_dist_lap_topology' in kwargs:
        eigenvalues = kwargs['eigenvalues_dist_lap_topology']
    else:
        from phylomodels.features.trees.helper.get_eigenvalues_dist_lap import get_eigenvalues_dist_lap
        eigen = get_eigenvalues_dist_lap(trees, topology_only=topology_only)
        if topology_only:
            eigenvalues = eigen['eigenvalues_dist_lap_topology']
        else:
            eigenvalues = eigen['eigenvalues_dist_lap']
		
    # Initialize output dataframe
    eigenvalue_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        w = eigenvalues[name]
        eig = np.amax(w)
        eigenvalue_df.loc[name, feature_name] = np.real(eig)


    return eigenvalue_df
