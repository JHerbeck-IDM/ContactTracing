import numpy as np
import pandas as pd

def sackin_var(trees, **kwargs):
    """
    Return varience in the numder of nodes between the leaves and root. If an
    attribute is given this is calucaled for each unique value of the attribute
    among the leaf nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The varience in the number of nodes between
                                   the leaves and the root for the whole tree 
                                   and if an attr is provided, conditionally 
                                   for each unique value of the attribute.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    sackin_vars_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs = []
            sackin_var     = []
            for node in tree.iter_leaves():
                node_attrs.append(getattr(node, attr))
                sackin_var.append(tree.get_distance(node, topology_only=True))
            sackin_var = np.array(sackin_var)
            node_attrs = np.array(node_attrs)
            sackin_vars_df.loc[name, 'sackin_var'] = np.var(sackin_var)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If sackin_var[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    sackin_vars_df.loc[name, 'sackin_var_' + attr_value] = 0.0
                else:
                    sackin_vars_df.loc[name, 'sackin_var_' + attr_value] = np.var(sackin_var[attr_value==node_attrs])
        # If not using attr option we only need the branch lengths
        else:
            sackin_var = []
            for node in tree.iter_leaves():
                sackin_var.append(tree.get_distance(node, topology_only=True))
            sackin_var = np.array(sackin_var)
            sackin_vars_df.loc[name, 'sackin_var'] = np.var(sackin_var)
            
    # Finalize and return
    return sackin_vars_df
