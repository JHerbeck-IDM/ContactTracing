import numpy as np

def get_eigenvalues_lap(trees, **kwargs):
    """
    Returns a dictionary containing the eigenvalues of the laplacian matrix for
    each tree that is in the input dictionary of trees.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of
                                   branches) instead of branch lengths.

    Returns:
        dict                     : A dictionary with each key being one of the
                                   input trees. The value is a list of
                                   eigenvalues for the laplacian matrix.

    """

    # Check if we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}

    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'eigenvalues_lap_topology'
    else:
        feature_name = 'eigenvalues_lap'

    if 'adjacency_mat' in kwargs:
        adjacency_mats = kwargs['adjacency_mat']
    elif 'adjacency_mat_topology' in kwargs:
        adjacency_mats = kwargs['adjacency_mat_topology']
    else:
        from phylomodels.features.trees.helper.get_adjacency_mat import get_adjacency_mat
        dist_mats = get_adjacency_mat(trees, topology_only=topology_only)
        if topology_only:
            adjacency_mats = dist_mats['adjacency_mat_topology']
        else:
            adjacency_mats = dist_mats['adjacency_mat']

    # Initialize dictionary for output
    eigenvalues_lap = {}

    # Compute the eigenvalues
    for name, tree in trees.items():
        D = np.sum(adjacency_mats[name], axis=0)
        laplacian = -adjacency_mats[name]
        np.fill_diagonal(laplacian, D)
        w = np.linalg.eigvals(laplacian)
        w[np.abs(w)<5e-15] = 0
        eigenvalues_lap[name] = w

    return {feature_name: eigenvalues_lap}
