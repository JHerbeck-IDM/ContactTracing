def tree_param(func):

    """Check the incoming 'trees' param and make a small dictionary if necessary"""

    def wrapper(trees, **kwargs):

        trees = trees if isinstance(trees, dict) else {"tree": trees}
        return func(trees, **kwargs)

    return wrapper

def attr_param(func):

    """Check kwargs for 'attr' and 'attr_values', extracting if present else pass 'None'"""

    def wrapper(trees, **kwargs):

        attr = kwargs.pop('attr', None)
        attr_values = kwargs.pop('attr_values', None)
        if attr:
            if attr_values is None:
                from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
                attr_values = unique_node_attr(trees, attr)['attr_values']
        return func(trees, attr, attr_values, **kwargs)

    return wrapper

def LTT_param(func):

    """Check kwargs for 'LTTs', extracting if present else get it"""

    def wrapper(trees, **kwargs):

        LTTs = kwargs.pop('LTTs', None)
        if LTTs is None:
            from phylomodels.features.trees.helper.get_LTT import get_LTT
            LTTs = get_LTT(trees)['LTTs']

        return func(trees, LTTs, **kwargs)

    return wrapper

def groups_param(func):

    """Check kwargs for 'group_sizess', extracting if present else get it"""

    def wrapper(trees, attr=None, attr_values=None, **kwargs):

        group_sizes = kwargs.pop('group_sizes', None)
        if group_sizes is None:
            from phylomodels.features.trees.helper.get_groups import get_groups
            group_sizes = get_groups(trees, attr, attr_values)['group_sizes']

        return func(trees, attr, attr_values, group_sizes, **kwargs)

    return wrapper

def topology_param(**kwargs):

    """Check kwargs for 'topology_only', extracting if present else pass 'False'"""

    topology_only = kwargs.pop('topology_only', False)

    return topology_only, kwargs

def threshold_param(**kwargs):

    """Check kwargs for 'threshold', extracting if present else pass '0'"""

    threshold = kwargs.pop('threshold', 0)

    return threshold, kwargs

def tau_param(**kwargs):

    """Check kwargs for 'tau', extracting if present else pass '0.4'"""

    tau = kwargs.pop('tau', 0.4)

    return tau, kwargs

def transform_param(**kwargs):

    """Check kwargs for 'transform', extracting if present else pass 'lambda x:x'"""

    transform = kwargs.pop('transform', lambda x:x)

    return transform, kwargs

def distLap_eigenvalues_param(trees, topology_only, **kwargs):

    """Check kwargs for 'eigenvalues_dist_lap' or 'eigenvalues_dist_lap_topology', extracting if present else get it"""

    if topology_only:
        eigenvalues = kwargs.pop('eigenvalues_dist_lap_topology', None)
    else:
        eigenvalues = kwargs.pop('eigenvalues_dist_lap', None)

    if eigenvalues is None:
        from phylomodels.features.trees.helper.get_eigenvalues_dist_lap import get_eigenvalues_dist_lap
        eigen = get_eigenvalues_dist_lap(trees, topology_only=topology_only)
        if topology_only:
            eigenvalues = eigen['eigenvalues_dist_lap_topology']
        else:
            eigenvalues = eigen['eigenvalues_dist_lap']

    return eigenvalues, kwargs

def lap_eigenvalues_param(trees, topology_only, **kwargs):

    """Check kwargs for 'eigenvalues_lap' or 'eigenvalues_lap_topology', extracting if present else get it"""

    if topology_only:
        eigenvalues = kwargs.pop('eigenvalues_lap_topology', None)
    else:
        eigenvalues = kwargs.pop('eigenvalues_lap', None)

    if eigenvalues is None:
        from phylomodels.features.trees.helper.get_eigenvalues_lap import get_eigenvalues_lap
        eigen = get_eigenvalues_lap(trees, topology_only=topology_only)
        if topology_only:
            eigenvalues = eigen['eigenvalues_lap_topology']
        else:
            eigenvalues = eigen['eigenvalues_lap']

    return eigenvalues, kwargs

def adj_eigenvalues_param(trees, topology_only, **kwargs):

    """Check kwargs for 'eigenvalues_adj' or 'eigenvalues_adj_topology', extracting if present else get it"""

    if topology_only:
        eigenvalues = kwargs.pop('eigenvalues_adj_topology', None)
    else:
        eigenvalues = kwargs.pop('eigenvalues_adj', None)

    if eigenvalues is None:
        from phylomodels.features.trees.helper.get_eigenvalues_adj import get_eigenvalues_adj
        eigen = get_eigenvalues_adj(trees, topology_only=topology_only)
        if topology_only:
            eigenvalues = eigen['eigenvalues_adj_topology']
        else:
            eigenvalues = eigen['eigenvalues_adj']

    return eigenvalues, kwargs

def distance_mat_param(trees, topology_only, **kwargs):

    """Check kwargs for 'distance_mat' or 'distance_mat_topology', extracting if present else get it"""

    if topology_only:
        distance_mats = kwargs.pop('distance_mat_topology', None)
    else:
        distance_mats = kwargs.pop('distance_mat', None)

    if distance_mats is None:
        from phylomodels.features.trees.helper.get_distance_mat import get_distance_mat
        dist_mats = get_distance_mat(trees, topology_only=topology_only)
        if topology_only:
            distance_mats = dist_mats['distance_mat_topology']
        else:
            distance_mats = dist_mats['distance_mat']

    return distance_mats, kwargs

def adjacency_mat_param(trees, topology_only, **kwargs):

    """Check kwargs for 'adjacency_mat' or 'adjacency_mat_topology', extracting if present else get it"""

    if topology_only:
        adjacency_mats = kwargs.pop('adjacency_mat_topology', None)
    else:
        adjacency_mats = kwargs.pop('adjacency_mat', None)

    if adjacency_mats is None:
        from phylomodels.features.trees.helper.get_adjacency_mat import get_adjacency_mat
        dist_mats = get_adjacency_mat(trees, topology_only=topology_only)
        if topology_only:
            adjacency_mats = dist_mats['adjacency_mat_topology']
        else:
            adjacency_mats = dist_mats['adjacency_mat']

    return adjacency_mats, kwargs
