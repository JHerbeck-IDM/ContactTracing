import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.check_values import check_branch_lengths
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, functions_param, branch_param

@tree_param
@attr_param
def calculate_branch_length_metrics(trees, attr, attr_values, **kwargs):
    """
    Return metrics based on the branch length of a tree or dict of trees. The
    user can provide the function used on the list of branch lengths. They can
    also specify whether to calculate on all branch lengths, external branchs,
    internal branches, or the ratio of internal and external. If an attribute
    is provided, these statistics are calculated for "all" branch lengths and
    conditionally for each unique value of the attribute.

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and building
                               a list of values found in them.
        functions_dict (dict): Optional. Dictionary where the keys are used for
                               naming the statistics and the values are
                               function handles for calculating the statistics.
                               By default it calculates min, max, mean, median
                               and standard deviation.
        branch_type (str)    : Optional (default "All"). This can be either
                               "All", "Internal", "External", or "Ratio".
                               Anything else will be interpreted as "All". This
                               controls whether to use all branches, only
                               internal or external branches, or their ratio.

    Returns:
        DataFrame            : Data frame containing the maximum branch length
                               of the tree(s), and if attr is provided, the
                               conditional maximum based on the node attribute
                               (as different columns).
    """

    # Process optional arguements
    functions_dict, kwargs = functions_param(**kwargs)
    branch_type,    kwargs = branch_param(**kwargs)

    # Initialize output dataframe
    BL_metrics_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # Create dataframe to hold data
        nodes = tree.get_descendants()
        num_nodes = len(nodes)
        df = pd.DataFrame(columns=['BL', 'attr', 'leaf'], index=range(num_nodes))
        for i, node in enumerate(nodes):
            df.loc[i, 'BL'] = node.dist
            df.loc[i, 'attr'] = getattr(node.up, attr, "None") if attr else None
            df.loc[i, 'leaf'] = node.is_leaf()

        # reduce dataframe if only looking at a subset of the branches
        if branch_type == 'internal':
            df = df[df['leaf'] == 0]
            stat_name = '_in_branch_length'
        elif branch_type == 'external':
            df = df[df['leaf'] == 1]
            stat_name = '_ex_branch_length'
        elif branch_type == 'ratio':
            stat_name = '_ratio_branch_length'
        else:
            stat_name = '_branch_length'

        check_branch_lengths(df['BL'])

        if branch_type == 'ratio':
            for f_name, function in functions_dict.items():
                # get internal and external cuts
                df_in = df[df['leaf'] == 0]
                df_ex = df[df['leaf'] == 1]
                del df
                value_in = function(df_in['BL'])
                value_ex = function(df_ex['BL'])
                if value_in==0 and value_ex==0:
                    BL_metrics_df.loc[name, f_name + stat_name] = 1.0
                else:
                    try:
                        BL_metrics_df.loc[name, f_name + stat_name] = value_in/value_ex
                    except ZeroDivisionError:
                        BL_metrics_df.loc[name, f_name + stat_name] = float('NaN')
                if attr:
                    for attr_value in attr_values:
                        idx_in = attr_value==df_in['attr']
                        idx_ex = attr_value==df_ex['attr']
                        # If branch_lengths[idx] returns an empty array the numpy functions will fail
                        if np.any(idx_in) and np.any(idx_ex):
                            value_in = function(df_in['BL'][idx_in])
                            value_ex = function(df_ex['BL'][idx_ex])
                            if value_in==0 and value_ex==0:
                                BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = 1.0
                            else:
                                try:
                                    BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = value_in/value_ex
                                except ZeroDivisionError:
                                    BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = float('NaN')
                        elif np.any(idx_in) and not np.any(idx_ex):
                            BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = float('inf')
                        elif not np.any(idx_in) and np.any(idx_ex):
                            BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = 0.0
                        else:
                            BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = 1.0
        else:
            for f_name, function in functions_dict.items():
                BL_metrics_df.loc[name, f_name + stat_name] = function(df['BL'])
                if attr:
                    for attr_value in attr_values:
                        idx = attr_value==df['attr']
                        # If branch_lengths[idx] returns an empty array the numpy functions will fail
                        if np.any(idx):
                            BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = function(df['BL'].values[idx])
                        else:
                            BL_metrics_df.loc[name, f_name + stat_name + '_' + attr_value] = 0.0

    # Finalize and return
    return BL_metrics_df
