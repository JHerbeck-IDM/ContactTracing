import numpy as np

def get_adjacency_mat(trees, **kwargs):
    """
    Returns a dictionary containing the adjacency matrix for each tree that is
    in the input dictionary of trees.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of
                                   branches) instead of branch lengths.

    Returns:
        dict                     : A dictionary with each key being one of the
                                   input trees. The value is a the adjacency
                                   maxtrix for the tree.

    """

    # Check if we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}

    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'adjacency_mat_topology'
    else:
        feature_name = 'adjacency_mat'

    # Initialize dictionary for output
    adjacency_mats = {}

    # Compute the eigenvalues
    for name, tree in trees.items():
        nodes = [tree] + tree.get_descendants('levelorder')
        num_nodes = len(nodes)
        nodes = {node: i for i, node in enumerate(nodes)}
        adjacency = np.zeros((num_nodes, num_nodes))
        if topology_only:
            for node, i in nodes.items():
                for child in node.children:
                    adjacency[i, nodes[child]] = 1
                    adjacency[nodes[child], i] = 1
        else:
            for node, i in nodes.items():
                for child in node.children:
                    adjacency[i, nodes[child]] = child.dist
                    adjacency[nodes[child], i] = child.dist
        adjacency_mats[name] = adjacency

    return {feature_name: adjacency_mats}
