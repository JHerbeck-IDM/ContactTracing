#from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

#@tree_param
#@attr_param
def get_groups(trees, attr=None, attr_values=None, **kwargs):
    """
    Return the dictionary with a list of group sizes for each value of the 
    attribute, where a group is defined as a connected set of nodes with the
    same value for an attribute. If no attribute is given the function will
    determine that all nodes belong to the same group and return a list with
    the number of nodes (instead of throwing an error).

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could
                                   take (or at least the ones we are
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The dictionary with the list of group sizes
                                   for each value of the provided attribute.

    """

    def match_descendents(root, nodes):
        nodes.remove(root)
        group_size = 1
        for child in root.children:
            if( getattr(root, attr)==getattr(child, attr)):
                group_size += match_descendents(child, nodes)
        return group_size

    # Compute the groups
    group_sizes = {}
    for name, tree in trees.items():
        groups = {}
        if attr:
            nodes = list(tree.traverse("levelorder"))
            for attr_value in attr_values:
                groups[attr_value] = []

            while(nodes):
                root = nodes[0]
                nodes.remove(root)
                group_size = 1
                for child in root.children:
                    if(getattr(root, attr)==getattr(child, attr)):
                        group_size += match_descendents(child, nodes)
                groups[getattr(root, attr)].append(group_size)

        group_sizes[name] = groups

    return {'group_sizes': group_sizes}
