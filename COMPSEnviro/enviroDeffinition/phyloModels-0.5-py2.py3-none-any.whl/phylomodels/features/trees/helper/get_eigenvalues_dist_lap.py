import numpy as np
from scipy import linalg

def get_eigenvalues_dist_lap(trees, **kwargs):
    """
    Returns a dictionary containing the eigenvalues of the distance laplacian
    matrix for each tree that is in the input dictionary of trees.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of
                                   branches) instead of branch lengths.

    Returns:
        dict                     : A dictionary with each key being one of the
                                   input trees. The value is a list of
                                   eigenvalues for the distance laplacian
                                   matrix.

    """

    # Check if we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}

    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'eigenvalues_dist_lap_topology'
    else:
        feature_name = 'eigenvalues_dist_lap'

    if 'distance_mat' in kwargs:
        distance_mats = kwargs['distance_mat']
    elif 'distance_mat_topology' in kwargs:
        distance_mats = kwargs['distance_mat_topology']
    else:
        from phylomodels.features.trees.helper.get_distance_mat import get_distance_mat
        dist_mats = get_distance_mat(trees, topology_only=topology_only)
        if topology_only:
            distance_mats = dist_mats['distance_mat_topology']
        else:
            distance_mats = dist_mats['distance_mat']

    # Initialize dictionary for output
    eigenvalues_dist_lap = {}

    # Compute the eigenvalues
    for name, tree in trees.items():
        D = np.sum(distance_mats[name], axis=0)
        laplacian = -distance_mats[name]
        np.fill_diagonal(laplacian, D)
        w = linalg.eigvalsh(laplacian)
        max_val = max(np.abs(w))
        thershold = max_val*1e-6
        w[np.abs(w)<thershold] = 0
        eigenvalues_dist_lap[name] = w

    return {feature_name: eigenvalues_dist_lap}
