import pandas as pd
from collections import Counter

def max_dW(trees, **kwargs):
    """
    Return the maximum difference in width between neighboring levels.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.

    Returns:
        DataFrame                : The maximum difference between neighboring
                                   levels.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    dWs = []    
    # Initialize output dataframe
    dWs_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():      
        depths = []
        for node in tree.iter_descendants():
            depths.append( tree.get_distance(node, topology_only=True) )
        
        widths = Counter(depths)
        depths = sorted(list(widths.keys()))
        dW = 0
        for i in range(len(depths)-1):
            dW = max(dW, abs(widths[depths[i]]-widths[depths[i+1]]))
        dWs_df.loc[name, 'max_dW'] = dW

    # Finalize and return
    return  dWs_df
