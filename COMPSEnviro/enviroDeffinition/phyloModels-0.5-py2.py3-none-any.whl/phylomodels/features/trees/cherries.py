import numpy as np
import pandas as pd

#TODO normalize somehow
def cherries(trees, **kwargs):
    """
    Return the number of nodes with a cherry (2 tips as child). Currently, we
    are not checking if the tree is bifurcating so we are really checking for 
    internal nodes with tip children that are not in ladders. If an attribute
    is suppled this fraction is also calculated conditionally for each value of 
    the attribute
    
    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : Data frame containing the number of 
                                   nodes are the stem of cherries for the 
                                   tree and if attr is provided the conditional
                                   fraction of nodes in cherry_arrays based on 
                                   the node attribute (as different columns). 
                                   Each tree having its own row.
                                   
    """

    def is_preterminal(node):
        return all(child.is_leaf() for child in node.children)    
    
    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    cherries_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            cherry_array = []
            node_attrs   = []
            for node in tree.traverse('levelorder'):
                if not node.is_leaf():
                    if is_preterminal(node):
                        cherry_array.append(True)
                    else:
                        cherry_array.append(False)
                    node_attrs.append(getattr(node, attr))
            cherry_array = np.array(cherry_array)
            node_attrs = np.array(node_attrs)
            cherries_df.loc[name, 'cherries'] = np.sum(cherry_array)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If cherry_array[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    cherries_df.loc[name, 'cherries_' + attr_value] = 0.0
                else:
                    cherries_df.loc[name, 'cherries_' + attr_value] = np.sum(cherry_array[idx])
        # If not using attr option we only need the branch lengths
        else:
            cherry_array     = []
            for node in tree.traverse('levelorder'):
                if not node.is_leaf():
                    if is_preterminal(node):
                        cherry_array.append(True)
                    else:
                        cherry_array.append(False)
            cherries_df.loc[name, 'cherries'] = np.sum(cherry_array)
            
    # Finalize and return
    return cherries_df
