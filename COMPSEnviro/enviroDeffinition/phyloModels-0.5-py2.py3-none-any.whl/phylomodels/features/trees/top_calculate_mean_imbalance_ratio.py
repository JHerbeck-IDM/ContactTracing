import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
def top_calculate_mean_imbalance_ratio(trees, attr, attr_values, **kwargs):
    """
    Return the mean ratio of the minimum number of leaves to the maximum number
    of leaves.
    Colijn and Gardy Evolution, Medicine, and Public Health 2014(1) p.96-108 (2014)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and buildng
                               a list of values found in them.

    Returns:
        DataFrame            : The mean ratio of the number of leaves on one
                               side and the other for the whole tree and if an
                               attr is provided conditionally for each unique
                               value of the attribute.

    """

    # Initialize output dataframe
    mean_imbalance_ratios_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        imbalance_ratio = []
        node_attrs      = []
        for node in tree.traverse():
            if not node.is_leaf():
                children = node.children
                # Start by setting the min and max to the number of leaves
                # under the 0th child
                min_leaves = len(children[0])
                max_leaves = len(children[0])
                # Loop through all children to make sure we really have the
                # min and max.
                for child in children:
                    min_leaves = min(min_leaves, len(child))
                    max_leaves = max(max_leaves, len(child))
                imbalance_ratio.append( min_leaves/max_leaves)
                node_attrs.append(getattr(node, attr, "None")) if attr else None
        imbalance_ratio = np.array(imbalance_ratio)

        mean_imbalance_ratios_df.loc[name, 'mean_imbalance_ratio'] = np.mean(imbalance_ratio)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_not_equals[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    mean_imbalance_ratios_df.loc[name, 'mean_imbalance_ratio_' + attr_value] = np.mean(imbalance_ratio[attr_value==node_attrs])
                else:
                    mean_imbalance_ratios_df.loc[name, 'mean_imbalance_ratio_' + attr_value] = 0.0

    # Finalize and return
    return mean_imbalance_ratios_df
