import numpy as np
import pandas as pd

def LBI_mean(trees, **kwargs):
    '''
    Return the mean local branching index. The local branching index is 
    calculatied by traversing the tree in postorder and preorder to calculate
    the up and downstream tree length exponentially weighted by distance.
    then adds them as LBI.
    I do not fully understand what is happening here. I have mostly just copied
    from nextstrain and striped down the function. We may want to look into 
    this more and add more options.

    Args:
        trees (ete3.Tree or dict) : The tree (or dict of trees) to calculate 
                                    the statistic from.
        attr (str)                : The name of the attribute to use in 
                                    conditionally calculating the statistic
        attr_values (ndarray)     : List of the unique values that attr could 
                                    take (or at least the ones we are 
                                    interested) in. If not provided it will be
                                    calculated by looping over all trees and 
                                    buildng a list of values found in them.
        tau (float)                : The rate for the exponentially weighted 
                                    distance.
        transform (lambda function): Function to transform into the final LBI.

    Returns:
        DataFrame                  : The mean LBI for the tree and 
                                     conditionally on an attribute if provided.

    '''

    # def select_nodes_in_season(tree, timepoint=0, time_window=0.6, **kwargs):
    #     """Annotate a boolean to each node in the tree if it is alive at the given
    #     timepoint or prior to the timepoint by the given time window preceding.
    #     This annotation is used by the LBI and epitope cross-immunity predictors.
    #     """
    #     for node in tree.find_clades(order="postorder"):
    #         node.alive=True
    #     #    if node.is_terminal():
    #     #        if node.attr['num_date'] <= timepoint and node.attr['num_date'] > timepoint - time_window:
    #     #            node.alive=True
    #     #        else:
    #     #            node.alive=False
    #     #    else:
    #     #        node.alive = any(ch.alive for ch in node.clades)

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Set tau if not passed in
    if 'tau' in kwargs:
        tau = kwargs['tau']
    else:
        tau = 0.4
        
    # Set transform if not passed in
    if 'transform' in kwargs:
        transform = kwargs['transform']
    else:
        transform = lambda x:x
        
    # Initialize output dataframe
    mean_LBI_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # select_nodes_in_season(tree)
    
        # traverse the tree in postorder (children first) to calculate msg to parents
        for node in tree.traverse("postorder"):
            node.add_feature("down_polarizer", 0)
            node.add_feature("up_polarizer", 0)
            for child in node.children:
                node.up_polarizer += child.up_polarizer
            bl =  node.dist / tau
            node.up_polarizer *= np.exp(-bl)
            # if node.alive: node.up_polarizer += tau*(1-np.exp(-bl))
            node.up_polarizer += tau*(1-np.exp(-bl))
    
        # traverse the tree in preorder (parents first) to calculate msg to children
        for node in tree.traverse("preorder"):
            for child1 in node.children:
                child1.down_polarizer = node.down_polarizer
                for child2 in node.children:
                    if child1!=child2:
                        child1.down_polarizer += child2.up_polarizer
    
                bl =  child1.dist / tau
                child1.down_polarizer *= np.exp(-bl)
                # if child1.alive: child1.down_polarizer += tau*(1-np.exp(-bl))
                child1.down_polarizer += tau*(1-np.exp(-bl))
    
        # go over all nodes and calculate the LBI (can be done in any order)
        max_LBI = 0.0
        for node in tree.traverse("levelorder"):
            tmp_LBI = node.down_polarizer
            for child in node.children:
                tmp_LBI += child.up_polarizer
    
            node.add_feature("LBI", transform(tmp_LBI))
            if node.LBI > max_LBI:
                max_LBI = node.LBI
    
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs = []
            LBI        = []
            # Normalize LBI to range [0, 1].
            for node in tree.traverse("levelorder"):
                node.LBI /= max_LBI
                LBI.append(node.LBI)
                node_attrs.append(getattr(node, attr))
            LBI = np.array(LBI)
            node_attrs = np.array(node_attrs)
            mean_LBI_df.loc[name, 'mean_LBI'] = np.mean(LBI)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If branch_lengths[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    mean_LBI_df.loc[name, 'mean_LBI_' + attr_value] = 0.0
                else:
                    mean_LBI_df.loc[name, 'mean_LBI_' + attr_value] = np.mean(LBI[idx])
        else:
            LBI = []
            # Normalize LBI to range [0, 1].
            for node in tree.traverse("levelorder"):
                node.LBI /= max_LBI
                LBI.append(node.LBI)            
            mean_LBI_df.loc[name, 'mean_LBI'] = np.mean(LBI)
    
    return mean_LBI_df
