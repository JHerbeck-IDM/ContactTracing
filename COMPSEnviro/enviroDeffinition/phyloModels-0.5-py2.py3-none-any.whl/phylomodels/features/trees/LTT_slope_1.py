import numpy as np
import pandas as pd

def LTT_slope_1(trees, **kwargs):
    """
    Returns the slope beteween the origin and the maximal number of lineages 
    from the lineages through time plot/view of the tree.
    
    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.

    Returns:
        DataFrame                : Data frame containing the slope from the
                                   root to the widest point of the tree 
                                   (maximum number of lineages)
                                                                  
    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Get LTT "plot"
    if 'LTTs' in kwargs:
        LTTs = kwargs['LTTs']
    else:
        from phylomodels.features.trees.helper.get_LTT import get_LTT
        LTTs = get_LTT(trees)['LTTs']

    # Initialize output dataframe
    slope_1_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():      
        times = np.array(list(LTTs[name].keys()))
        t_max_L = max(LTTs[name], key=LTTs[name].get)
        slope_1_df.loc[name, 'slope_1'] = (LTTs[name][t_max_L]-LTTs[name][times[0]])/(t_max_L-times[0])


    # Finalize and return
    return  slope_1_df
