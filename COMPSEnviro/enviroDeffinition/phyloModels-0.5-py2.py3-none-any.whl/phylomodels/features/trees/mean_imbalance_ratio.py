import numpy as np
import pandas as pd

def mean_imbalance_ratio(trees, **kwargs):
    """
    Return the mean ratio of  the number of leaves on one side and the other.
    We will always take the smaller ratio. To calculate summary static a tree
    must be bifurcating. I believe there are ways around that requirement,
    but have not looked into it yet.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The mean ratio of the number of leaves on 
                                   one side and the other for the whole tree 
                                   and if an attr is provided conditionally 
                                   for each unique value of the attribute.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    mean_imbalance_ratios_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs     = []
            imbalance_ratio = []
            for node in tree.traverse():
                if not node.is_leaf():
                    children = node.children
                    if len(children) != 2:
                        raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
                    # Get the attribute of the node
                    node_attrs.append(getattr(node, attr))
                    imbalance_ratio.append(min(len(children[0])/len(children[1]), len(children[1])/len(children[0])))
            imbalance_ratio = np.array(imbalance_ratio)
            node_attrs = np.array(node_attrs)
            mean_imbalance_ratios_df.loc[name, 'mean_imbalance_ratio'] = np.mean(imbalance_ratio)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_not_equals[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    mean_imbalance_ratios_df.loc[name, 'mean_imbalance_ratio_' + attr_value] = 0.0
                else:
                    mean_imbalance_ratios_df.loc[name, 'mean_imbalance_ratio_' + attr_value] = np.mean(imbalance_ratio[attr_value==node_attrs])
        # If not using attr option we only need the branch lengths
        else:
            imbalance_ratio = []
            for node in tree.traverse():
                if not node.is_leaf():
                    children = node.children
                    if len(children) != 2:
                        raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
                    imbalance_ratio.append(min(len(children[0])/len(children[1]), len(children[1])/len(children[0])))
            imbalance_ratio = np.array(imbalance_ratio)
            mean_imbalance_ratios_df.loc[name, 'mean_imbalance_ratio'] = np.mean(imbalance_ratio)
            
    # Finalize and return
    return mean_imbalance_ratios_df
