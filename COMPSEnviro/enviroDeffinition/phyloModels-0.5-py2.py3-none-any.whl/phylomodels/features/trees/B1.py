import numpy as np
import pandas as pd

def B1(trees, **kwargs):
    """
    Return inverse sum of the maximum numder of nodes between the leaves and 
    each internal node (excluding the root). If an attribute is given this is 
    calculated for each unique value of the attribute among the internal nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The inverse sum of the maximum number of 
                                   nodes between the leaves and each internal
                                   node for the whole tree and if an attr is 
                                   provided, conditionally for each unique 
                                   value of the attribute.

    """

    # Check if we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    B1_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs = []
            M          = []
            for node in tree.iter_descendants():
                if not node.is_leaf():
                    node_attrs.append(getattr(node, attr))
                    _, M_i = node.get_farthest_leaf(topology_only=True)
                    # add 1 so a pretermius node is not 0, seems to be what the
                    # diffination intended
                    M.append(M_i+1)
            M = np.array(M)
            node_attrs = np.array(node_attrs)
            B1_df.loc[name, 'B1'] = np.sum(1/M)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If M[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    B1_df.loc[name, 'B1_' + attr_value] = 0.0
                else:
                    B1_df.loc[name, 'B1_' + attr_value] = np.sum(1/M[idx])
        # If not using attr option we only need the branch lengths
        else:
            M = []
            for node in tree.iter_descendants():
                if not node.is_leaf():
                    _, M_i = node.get_farthest_leaf(topology_only=True)
                    # add 1 so a pretermius node is not 0, seems to be what the
                    # diffination intended
                    M.append(M_i+1)
            M = np.array(M)
            B1_df.loc[name, 'B1'] = np.sum(1/M)
            
    # Finalize and return
    return B1_df
