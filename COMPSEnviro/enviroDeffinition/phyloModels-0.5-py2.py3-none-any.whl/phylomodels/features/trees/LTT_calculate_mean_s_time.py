import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, LTT_param

@tree_param
@LTT_param
def LTT_calculate_mean_s_time(trees, LTTs, **kwargs):
    """
    Returns the mean time between two consecutive down steps (mean sampling
    time) from the lineages through time plot/view of the tree.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict): The dict of trees to calculate the statistic from.
        LTTs (dict) : Optional. A dictionary with each key being one of the
                      input trees. The value is a dictionary represention of
                      the lineage through time plot.

    Returns:
        DataFrame   : Data frame containing the mean step down time.

    """

    # Initialize output dataframe
    mean_s_time_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        times = np.array(list(LTTs[name].keys()))
        lin_diff = np.diff(list(LTTs[name].values()))
        lin_diff = np.append(0,lin_diff)
        step_down_times = times[lin_diff<0]
        mean_s_time_df.loc[name, 'mean_s_time'] = np.mean(np.diff(step_down_times))

    # Finalize and return
    return  mean_s_time_df
