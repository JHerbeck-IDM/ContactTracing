import numpy as np
import pandas as pd

#TODO look at allowing this to be broken up over time periods
def internal_branch_length_std(trees, **kwargs):
    """
    Return the standard deviation of the internal branch lengths. If an 
    attribute is provided these statistics are calculated for all internal 
    branch lengths and condtionally for each unique value of the attribute.

    Args:
        trees (ete3.Tree or list): The tree (or list of trees) to calculate the
                                   statistic from.
        attr (str)               : optional (default none), a node attrubute 
                                   for calculating the conditional statistic 
                                   from.

    Returns:
        DataFrame                : Data frame containing the standard deviation
                                   internal branch length for the tree and if 
                                   attr is provided the conditional standard 
                                   deviation based on the node attribute (as 
                                   different columns). Each tree having its own
                                   row.
                                   
    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    std_BLs_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs     = []
            branch_lengths = []
            for node in tree.iter_descendants():
                if not node.is_leaf():
                    # Get the attribute of the parent node
                    node_attrs.append(getattr(node.up, attr))
                    branch_lengths.append(node.dist)
            branch_lengths = np.array(branch_lengths)
            node_attrs = np.array(node_attrs)
            std_BLs_df.loc[name, 'std_in_branch_length'] = np.std(branch_lengths)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If branch_lengths[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    std_BLs_df.loc[name, 'std_in_branch_length_' + attr_value] = 0.0
                else:
                    std_BLs_df.loc[name, 'std_in_branch_length_' + attr_value] = np.std(branch_lengths[idx])
        # If not using attr option we only need the branch lengths
        else:
            branch_lengths = []
            for node in tree.iter_descendants():
                if not node.is_leaf():
                    branch_lengths.append(node.dist)
            std_BLs_df.loc[name, 'std_in_branch_length'] = np.std(branch_lengths)
         
    # Finalize and return
    return std_BLs_df
