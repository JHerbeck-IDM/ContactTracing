import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
#TODO normalize?
def netSci_calculate_betweenness_max(trees, attr, attr_values, **kwargs):
    """
    Return maximum betweenness of the nodes. If an attribute is given this is
    calucaled for each unique value of the attribute among the leaf nodes.
    Chindelevitch et al bioRxiv https://doi.org/10.1101/608646

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and building
                               a list of values found in them.

    Returns:
        DataFrame            : The maximum betweenness of the nodes for the
                               whole tree and if an attr is provided,
                               conditionally for each unique value of the
                               attribute.

    """

    # Initialize output dataframe
    betweenness_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # get nodes in reverse levelorder
        nodes = list(reversed([tree] + tree.get_descendants('levelorder')))
        N = len(nodes)
        clade_sizes = {}
        for node in nodes:
            sizes = []
            for child in node.children:
                sizes.append(sum(clade_sizes[child][:-1])+1)
            sizes.append(N - np.sum(sizes) - 1)
            clade_sizes[node] = sizes

        betweenness = []
        node_attrs  = []
        for node in nodes:
            sizes = clade_sizes[node]
            total = 0
            for i in range(len(sizes)):
                for j in range(i+1, len(sizes)):
                    total += sizes[i]*sizes[j]
            betweenness.append(total)
            node_attrs.append(getattr(node, attr, "None")) if attr else None
        betweenness = np.array(betweenness)

        betweenness_df.loc[name, 'betweenness_max'] = np.amax(betweenness)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If betweenness[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    betweenness_df.loc[name, 'betweenness_max_' + attr_value] = np.amax(betweenness[idx])
                else:
                    betweenness_df.loc[name, 'betweenness_max_' + attr_value] = 0.0

    # Finalize and return
    return betweenness_df
