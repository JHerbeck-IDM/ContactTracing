import numpy as np
import pandas as pd

def colless(trees, **kwargs):
    """
    Return sum of the different between the number of leaves on the left side
    and on the right for each node. For this summary static a tree must be
    bifurcating. There may be generalization for nonbifurcating trees, but I
    have not looked into it yet. If an attribute is given this is calculated
    for each unique value of the attribute among the internal nodes.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        attr (str)               : The name of the attribute to use in 
                                   conditionally calculating the statistic
        attr_values (ndarray)    : List of the unique values that attr could 
                                   take (or at least the ones we are 
                                   interested) in. If not provided it will be
                                   calculated by looping over all trees and 
                                   buildng a list of values found in them.

    Returns:
        DataFrame                : The sum of the difference in the number of 
                                   leaves on one side and the other for the 
                                   whole tree and if an attr is provided 
                                   conditionally for each unique value of the 
                                   attribute.

    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Initialize output dataframe
    collesses_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs     = []
            leaf_diffs = []
            for node in tree.traverse():
                if not node.is_leaf():
                    children = node.children
                    if len(children) != 2:
                        raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
                    # Get the attribute of the parent node
                    node_attrs.append(getattr(node, attr))
                    leaf_diffs.append(abs(len(children[0]) - len(children[1])))
            leaf_diffs = np.array(leaf_diffs)
            node_attrs = np.array(node_attrs)
            collesses_df.loc[name, 'colless'] = np.sum(leaf_diffs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_diffs[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    collesses_df.loc[name, 'colless_' + attr_value] = 0.0
                else:
                    collesses_df.loc[name, 'colless_' + attr_value] = np.sum(leaf_diffs[attr_value==node_attrs])
        # If not using attr option we only need the branch lengths
        else:
            leaf_diffs = []
            for node in tree.traverse():
                if not node.is_leaf():
                    children = node.children
                    if len(children) != 2:
                        raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
                    leaf_diffs.append(abs(len(children[0]) - len(children[1])))
            leaf_diffs = np.array(leaf_diffs)
            collesses_df.loc[name, 'colless'] = np.sum(leaf_diffs)
            
    # Finalize and return
    return collesses_df
