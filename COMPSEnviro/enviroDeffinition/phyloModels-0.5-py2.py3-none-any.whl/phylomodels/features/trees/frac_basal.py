import numpy as np
import pandas as pd

def frac_basal(trees, **kwargs):
    '''
    Return the fraction of leaves that are basal (probably parents of other 
    nodes) versus terminal (ends of transmission chains). 
    I may have over simplified this some. I am just checking for a short branch
    length not doing anything to make sure there really are down stream leaves.

    Args:
        trees (ete3.Tree or dict) : The tree (or dict of trees) to calculate 
                                    the statistic from.
        attr (str)                : The name of the attribute to use in 
                                    conditionally calculating the statistic
        attr_values (ndarray)     : List of the unique values that attr could 
                                    take (or at least the ones we are 
                                    interested) in. If not provided it will be
                                    calculated by looping over all trees and 
                                    buildng a list of values found in them.
        threshold (float)         : Minimum branch length to collapse.

    Returns:
        DataFrame                : The maximum eigenvalue of the adjacency 
                                   matrix for the tree.

    '''

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Check if attr was given
    if 'attr' in kwargs:
        attr = kwargs['attr']
        if 'attr_values' in kwargs:
            attr_values = kwargs['attr_values']
        else:
            from phylomodels.features.trees.helper.unique_node_attr import unique_node_attr
            attr_values = unique_node_attr(trees, attr)['attr_values']
    else:
        attr = None
        
    # Set thershold if not passed in
    if 'thershold' in kwargs:
        thershold = kwargs['thershold']
    else:
        thershold = 0
        
    # Initialize output dataframe
    frac_basal_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        # If using attr option get list of values along side the branch length
        # for conditional calculations
        if attr:
            node_attrs = []
            basal      = []
            # Normalize LBI to range [0, 1].
            for node in tree.traverse("levelorder"):
                basal.append(node.dist<=thershold)
                node_attrs.append(getattr(node, attr))
            basal = np.array(basal)
            node_attrs = np.array(node_attrs)
            frac_basal_df.loc[name, 'frac_basal'] = np.sum(basal)/len(basal)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If basal[idx] returns an empty array the numpy functions will fail
                if np.sum(idx) == 0:
                    frac_basal_df.loc[name, 'frac_basal_' + attr_value] = 0.0
                else:
                    frac_basal_df.loc[name, 'frac_basal_' + attr_value] = np.sum(basal[idx])/np.sum(idx)
        else:
            basal = []
            for node in tree.traverse("levelorder"):
                basal.append(node.dist<=thershold)           
            frac_basal_df.loc[name, 'frac_basal'] = np.sum(basal)/len(basal)
    
    return frac_basal_df
