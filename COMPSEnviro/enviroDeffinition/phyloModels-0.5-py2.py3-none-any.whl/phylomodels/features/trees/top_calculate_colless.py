import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, normalize_param

@tree_param
@attr_param
def top_calculate_colless(trees, attr, attr_values, **kwargs):
    """
    Return sum of the difference between the number of leaves on the left side
    and on the right for each node. Originally this summary static required a
    tree to be bifurcating. We have implemented a generalization for
    nonbifurcating trees, where we add up the absolute difference between the
    number of leaves that each pair of current of the current node. If an
    attribute is given this is calculated for each unique value of the
    attribute among the internal nodes.
    Colles Systematic Zoology 31(1) p.100-104 (1982)

    Args:
        trees (dict)          : The dict of trees to calculate the statistic
                                from.
        attr (str)            : Optional. The name of the attribute to use in
                                conditionally calculating the statistic.
        attr_values (ndarray) : Optional. List of the unique values that attr
                                could take (or at least the ones we are
                                interested) in. If not provided it will be
                                calculated by looping over all trees and
                                building a list of values found in them.
        normalize_param (bool): Optional. Whether or not to normalize the
                                statistics.

    Returns:
        DataFrame             : The sum of the difference in the number of
                                leaves on one side and the other for the whole
                                tree and if an attr is provided conditionally
                                for each unique value of the attribute.

    """

    # Process optional arguements
    normalize, kwargs = normalize_param(**kwargs)

    # Initialize output dataframe
    collesses_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        leaf_diffs = []
        node_attrs = []
        for node in tree.traverse():
            if not node.is_leaf():
                children = node.children
                # Start the imbalance for this node at 0 (none)
                leaf_diff = 0
                # Loop through all pairs of children and add up the leaf
                # differences.
                for i in np.arange(len(children)):
                    for j in np.arange(i+1, len(children)):
                        leaf_diff += abs(len(children[i]) - len(children[j]))
                leaf_diffs.append( leaf_diff )
                node_attrs.append(getattr(node, attr, "None")) if attr else None
        leaf_diffs = np.array(leaf_diffs)

        if normalize:
            collesses_df.loc[name, 'colless'] = np.sum(leaf_diffs)/len(leaf_diffs)
        else:
            collesses_df.loc[name, 'colless'] = np.sum(leaf_diffs)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                if normalize:
                    # If leaf_diffs[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        collesses_df.loc[name, 'colless_' + attr_value] = np.sum(leaf_diffs[idx])/np.sum(idx)
                    else:
                        collesses_df.loc[name, 'colless_' + attr_value] = 0.0
                else:
                    # If leaf_diffs[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        collesses_df.loc[name, 'colless_' + attr_value] = np.sum(leaf_diffs[idx])
                    else:
                        collesses_df.loc[name, 'colless_' + attr_value] = 0.0

    # Finalize and return
    return collesses_df
