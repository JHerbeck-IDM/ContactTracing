import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
def top_calculate_colless(trees, attr, attr_values, **kwargs):
    """
    Return sum of the difference between the number of leaves on the left side
    and on the right for each node. For this summary static a tree must be
    bifurcating. There may be generalization for nonbifurcating trees, but I
    have not looked into it yet. If an attribute is given this is calculated
    for each unique value of the attribute among the internal nodes.
    Colles Systematic Zoology 31(1) p.100-104 (1982)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and buildng
                               a list of values found in them.

    Returns:
        DataFrame            : The sum of the difference in the number of leaves
                               on one side and the other for the whole tree and
                               if an attr is provided conditionally for each
                               unique value of the attribute.

    """

    # Initialize output dataframe
    collesses_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        leaf_diffs = []
        node_attrs = []
        for node in tree.traverse():
            if not node.is_leaf():
                children = node.children
                if len(children) != 2:
                    raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
                leaf_diffs.append(abs(len(children[0]) - len(children[1])))
                node_attrs.append(getattr(node, attr)) if attr else None
        leaf_diffs = np.array(leaf_diffs)

        collesses_df.loc[name, 'colless'] = np.sum(leaf_diffs)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_diffs[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    collesses_df.loc[name, 'colless_' + attr_value] = np.sum(leaf_diffs[attr_value==node_attrs])
                else:
                    collesses_df.loc[name, 'colless_' + attr_value] = 0.0

    # Finalize and return
    return collesses_df
