import numpy as np
import pandas as pd
import sys

#TODO normalize by Z(n)?
def FurnasR(trees, **kwargs):
    """
    Return Furans's R, a left-ight rooted ranking that can serve as a measure
    of imbalance. For a 64 bit float we hit overflow (inf) issues once n gets 
    above 747 for now if we hit this limit we since anything that comes out as
    inf is set to sys.float.max.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.

    Returns:
        DataFrame                : The varience in the number of nodes between
                                   the leaves and the root for the whole tree 
                                   and if an attr is provided, conditionally 
                                   for each unique value of the attribute.

    """

    Z_array = [0]
    
    # Get Z value from a precalculated array
    def get_Z(i):
        if not float(i).is_integer():
            return 0
        return Z_array[int(i)]
    
    # Add values to the Z array
    def calculate_Z(n):
        for i in range(1,n+1):
            z = 0
            if i==1 or i==2:
                Z_array.append(1)
            elif not float(i).is_integer():
                raise Exception('Should pass an integer to colculate_Z')
            else:
                for j in np.arange(1, np.floor(i/2)+1):
                    z += get_Z(j)*get_Z(i-j)
                z += 0.5*get_Z(i/2)*(get_Z(i/2)+1)
                Z_array.append(z)    
        
    ## Recurvise function for finding the number of (unlabeled binary) trees 
    ## that exist with i leaves
    #def Z(i):
    #    z = 0
    #    i = float(i)
    #    if i==1 or i==2:
    #        return 1
    #    elif not i.is_integer():
    #        return 0
    #    else:
    #        for j in np.arange(1, np.floor(i/2)+1):
    #            z += Z(j)*Z(i-j)
    #        z += 0.5*Z(i/2)*(Z(i/2)+1)
    #    return z
    
    # Recurvise function for calculating the R rank
    def R(tree):
        RT = 0
        n = len(tree)
        children = tree.children
        if len(children)>2 or len(children)==1:
            raise Exception('The tree is not bifurcating, currently imbalance calculation assumes bifurcation.')
        elif len(children) == 0: # leaf node
            return 1
        r = len(children[0])
        s = len(children[1])
        RT_r = R(children[0])
        RT_s = R(children[1])
        if s > r:
            temp = s
            s = r
            r = temp
            temp = RT_s
            RT_s = RT_r
            RT_r = temp
        elif r==s:
            if RT_s > RT_r:
                temp = RT_s
                RT_s = RT_r
                RT_r = temp
        if r > s:
            for i in np.arange(s-1)+1:
                RT += get_Z(i)*get_Z(n-i)
            RT += (RT_s-1)*get_Z(r) + RT_r
        elif r == s:
            for i in np.arange(s-1)+1:
                RT += get_Z(i)*get_Z(n-i)
            RT += -get_Z(s) + (get_Z(s) - 0.5*RT_s + 0.5)*RT_s + RT_r
        else:
            raise Exception('You should not have reached this line of code. something is broken in FurnasR')
        if np.isinf(RT):
            RT = sys.float_info.max
        return RT
        
    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Initialize output dataframe
    Rs_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        Z_array = Z_array[:1]
        n = len(tree)
        calculate_Z(n)
        if np.any(np.isinf(Z_array)):
            idx = np.min(np.where(np.isinf(Z_array)))
            Z_array[idx:] = [sys.float_info.max] * (len(Z_array)-idx)
        R_temp = R(tree)
        if np.isinf(R_temp):
            R_temp = sys.float_info.max
        Rs_df.loc[name, 'Furnas_R'] = R_temp
            
    # Finalize and return
    return Rs_df
