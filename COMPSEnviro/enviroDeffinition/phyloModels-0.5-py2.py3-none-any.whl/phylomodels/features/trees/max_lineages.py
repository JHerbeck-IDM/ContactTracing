import pandas as pd

def max_lineages(trees, **kwargs):
    """
    Returns the maximum number of lineages from the lineages through time plot/
    view of the tree.
    
    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.

    Returns:
        DataFrame                : Data frame containing the maximum number of
                                   lineages.
                                                                  
    """

    # Check it we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}
        
    # Get LTT "plot"
    if 'LTTs' in kwargs:
        LTTs = kwargs['LTTs']
    else:
        from phylomodels.features.trees.helper.get_LTT import get_LTT
        LTTs = get_LTT(trees)['LTTs']

    # Initialize output dataframe
    max_Ls_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():      
        max_Ls_df.loc[name, 'max_lineages'] = max(LTTs[name].values())

    # Finalize and return
    return  max_Ls_df
