import numpy
import scipy
import pandas


def series_derivative2_laplaceFit(x, *args):
    """
    Returns the parameters of a Laplace distribution that fits the second
    derivative of the input time series. The output is a pandas dataframe.
    """

    dx   = numpy.gradient(x,  axis=1)
    dx2  = numpy.gradient(dx, axis=1)
    n    = len(dx2)
    mean = numpy.zeros(n)
    var  = numpy.zeros(n)
    for i in range(0,n):
        mean[i], var[i] = scipy.stats.laplace.fit(dx2[i,:])
    dx2LaplaceFit_df = pandas.DataFrame( { "dx2_laplace_mean": mean,
                                           "dx2_laplace_var" : var,
                                          }
                                        )
    return dx2LaplaceFit_df
