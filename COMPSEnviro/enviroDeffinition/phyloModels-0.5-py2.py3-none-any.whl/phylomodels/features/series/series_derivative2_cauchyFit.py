import numpy
import scipy
import pandas


def series_derivative2_cauchyFit(x, *args):
    """
    Returns the parameters of a Cauchy distribution that fits the second
    derivative of the input time series. The output is a pandas dataframe.
    """

    dx    = numpy.gradient(x,  axis=1)
    dx2   = numpy.gradient(dx, axis=1)
    n     = len(dx2)
    loc   = numpy.zeros(n)
    scale = numpy.zeros(n)
    for i in range(0,n):
        loc[i], scale[i] = scipy.stats.cauchy.fit( dx2[i,:] )
    dx2CauchyFit_df = pandas.DataFrame( { "dx2_cauchy_loc": loc,
                                          "dx2_cauchy_scale": scale,
                                         }
                                       )
    return dx2CauchyFit_df
