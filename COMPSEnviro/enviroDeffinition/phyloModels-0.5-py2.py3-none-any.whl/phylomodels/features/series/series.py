import numpy
import pandas


def series(x, *args):
    """
    Returns the array of time series as a pandas dataframe.
    """

    x_df = pandas.DataFrame(x)
    for i in x_df:
        x_df.rename( columns={ x_df.columns[i]: "x_" + str(i) }, inplace=True )
    return x_df
