import numpy
import pandas


def series_derivative2_gaussianFit(x, *args):
    """
    Returns the parameters of a Gaussian distribution that fits the second
    derivative of the input time series. The output is a pandas dataframe.
    """

    dx   = numpy.gradient(x,  axis=1)
    dx2  = numpy.gradient(dx, axis=1)
    mean = numpy.mean(dx2, axis=1)
    var  = numpy.var(dx2, axis=1)
    dx2GaussianFit_df = pandas.DataFrame( { "dx2_mean": mean,
                                            "dx2_var" : var,
                                           }
                                         )
    return dx2GaussianFit_df
