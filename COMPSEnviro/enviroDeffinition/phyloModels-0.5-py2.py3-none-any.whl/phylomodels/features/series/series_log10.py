import numpy
import pandas


def series_log10(x, *args):
    """
    Returns the logarithm in base 10 of the input time series as a pandas
    dataframe.
    """

    numpy.seterr(divide="ignore")
    xLog10 = numpy.log10(x)
    numpy.seterr(divide="warn")
    xLog10_df = pandas.DataFrame(xLog10)
    for i in xLog10_df:
        xLog10_df.rename( columns={ xLog10_df.columns[i]: "xLog10_" + str(i) },
                          inplace=True
                         )
    return xLog10_df
