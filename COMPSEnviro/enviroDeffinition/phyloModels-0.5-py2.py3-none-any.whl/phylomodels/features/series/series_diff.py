import numpy
import pandas


def series_diff(x, xref):
    """
    Returns the difference between each time series in x and xref. The output
    is a pandas dataframe.
    """

    m = len(x)
    diff = numpy.add( x, -numpy.repeat( xref, m, axis=0 ) )
    diff_df = pandas.DataFrame(diff)
    for i in diff_df:
        diff_df.rename( columns={ diff_df.columns[i]: "diff_" + str(i) },
                        inplace=True
                       )

    return diff_df
