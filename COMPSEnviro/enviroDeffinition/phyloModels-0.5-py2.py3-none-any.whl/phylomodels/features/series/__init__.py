from phylomodels.features.series import series
from phylomodels.features.series import series_sum
from phylomodels.features.series import series_sum_log10

from phylomodels.features.series import series_diff
from phylomodels.features.series import series_diff_L1
from phylomodels.features.series import series_diff_L2
from phylomodels.features.series import series_diff_Linf

from phylomodels.features.series import series_derivative
from phylomodels.features.series import series_derivative_cauchyFit
from phylomodels.features.series import series_derivative_gaussianFit
from phylomodels.features.series import series_derivative_laplaceFit

from phylomodels.features.series import series_derivative2
from phylomodels.features.series import series_derivative2_cauchyFit
from phylomodels.features.series import series_derivative2_gaussianFit
from phylomodels.features.series import series_derivative2_laplaceFit

from phylomodels.features.series import series_log10

from phylomodels.features.series import series_partialSum2
from phylomodels.features.series import series_partialSum7
from phylomodels.features.series import series_partialSum10
from phylomodels.features.series import series_partialSum15
from phylomodels.features.series import series_partialSum30
