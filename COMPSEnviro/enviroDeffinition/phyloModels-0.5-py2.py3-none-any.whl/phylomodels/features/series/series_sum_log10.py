import numpy
import pandas


def series_sum_log10(x, *args):
    """
    Returns Log10 of the sum of elements of each the time series as a pandas
    dataframe.
    """

    sum = x.sum( axis=1 )
    sum_df = pandas.DataFrame( {"sumLog10_x": numpy.log10(sum)} )
    return sum_df
