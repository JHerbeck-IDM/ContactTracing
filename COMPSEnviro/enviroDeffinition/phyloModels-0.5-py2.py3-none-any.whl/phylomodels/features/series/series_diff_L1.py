import numpy
import pandas


def series_diff_L1(x, xref):
    """
    Returns the L1 norm of the difference between each time series in x and
    xref. The output is a pandas dataframe.
    """

    m = len(x)
    diff = numpy.add( x, -numpy.repeat( xref, m, axis=0 ) )
    diff_L1 = numpy.linalg.norm( diff, ord=1, axis=1 )
    diff_L1_df = pandas.DataFrame( {"diff_L1": diff_L1} )
    return diff_L1_df
