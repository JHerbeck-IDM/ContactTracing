import numpy
import scipy
import pandas


def series_derivative_laplaceFit(x, *args):
    """
    Returns the parameters of a Laplace distribution that fits the
    derivative of the input time series. The output is a pandas dataframe.
    """

    dx  = numpy.gradient(x,  axis=1)
    n = len(dx)
    mean = numpy.zeros(n)
    var = numpy.zeros(n)
    for i in range(0,n):
        mean[i], var[i] = scipy.stats.laplace.fit(dx[i,:])
    dxLaplaceFit_df = pandas.DataFrame( { "dx_laplace_mean": mean,
                                          "dx_laplace_var" : var,
                                         }
                                       )
    return dxLaplaceFit_df
