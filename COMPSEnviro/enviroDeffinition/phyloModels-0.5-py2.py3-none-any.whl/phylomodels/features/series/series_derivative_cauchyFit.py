import numpy
import scipy
import pandas


def series_derivative_cauchyFit(x, *args):
    """
    Returns the parameters of a Cauchy distribution that fits the
    derivative of the input time series. The output is a pandas dataframe.
    """

    dx    = numpy.gradient(x,  axis=1)
    n     = len(dx)
    loc   = numpy.zeros(n)
    scale = numpy.zeros(n)
    for i in range(0,n):
        loc[i], scale[i] = scipy.stats.cauchy.fit( dx[i,:] )
    dxCauchyFit_df = pandas.DataFrame( { "dx_cauchy_loc": loc,
                                         "dx_cauchy_scale": scale,
                                        }
                                      )
    return dxCauchyFit_df
