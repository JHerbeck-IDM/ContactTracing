import numpy
import pandas


def skew(f):
    """
    Returns the unbiased skewness of each column of the input dataframe.
    """

    skew = f.skew(axis=0)
    skew_df = pandas.DataFrame( {"skew": skew} )
    return skew_df
