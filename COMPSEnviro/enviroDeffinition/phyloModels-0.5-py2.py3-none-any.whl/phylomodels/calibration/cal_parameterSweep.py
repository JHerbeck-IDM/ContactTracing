# Python libraries (native, 3rd party)
import numpy
import pandas
import math
import warnings


# Python libraries (IDM)
from history_matching import HistoryMatching,    \
                             HistoryMatchingCut, \
                             Basis




#-------------------------------------------------------------------------------
#   cal_parameterSweep
#-------------------------------------------------------------------------------
def cal_parameterSweep( xInfo  : pandas.DataFrame,
                        xInit  : pandas.DataFrame,
                        y      : pandas.DataFrame,
                        model,
                        params
                       ):
    """
    Find optimum value of the parameters of a model.

    Args:
     xInfo  : Name and range of model parameters. This is a pandas dataframe.
              The columns of xInfo are: "Name", "Min", and "Max", which refer
              to the name of a parameter, its lower bound, and its upper bound,
              respectively. Each row of xInfo contains information of one
              model parameter.
     xInit  : Initial value(s) (or guess) of model parameters. This is a pandas
              dataframe where columns refer (and are named according) to
              parameters of the model, and rows are initial values for the
              solver.
     y      : Observations. This is a pandas dataframe of the same
              characteristics of the model output.
     model  : Pointer to the model wrapper (or subroutine).
     params : Dictionary containing additional parameter sweep arguments. The
              arguments that can be defined in params are:

                trials
                    Number of times that the model should be executed
                    with each set of parameters.

                cost_metric
                    Cost metric used for each set of parameters. It can be:

                    - "L1"   : L-1 norm of the error
                    - "L2"   : L-2 norm of the error
                    - "Linf" : L-inf norm of the error

    Returns:
     The return value, which is a Pandas DataFrame.

    """

    # Set constants and parameters
    trials     =params.get("trials")      if ("trials"      in params) else 10
    costMetric =params.get("cost_metric") if ("cost_metric" in params) else "L1"
    y_np = y.to_numpy(copy=True)
    m = len(xInit)              # Number of rows
    n = numpy.ma.size(y_np,1)   # Number of columns


    # Run simulations and compute cost
    for i in range(0, trials):

        # Run model and compute difference with observations
        ySim = model(xInit)
        ySim_np = ySim.to_numpy(copy=True)
        diff = numpy.add( ySim_np, -numpy.repeat( y_np, m, axis=0 ) )

        # Compute cost
        if ( costMetric == "L1" ):
            norm = numpy.linalg.norm( diff, ord=1, axis=1 )
            cost = numpy.divide( norm, n )

        elif ( costMetric == "L2" ):
            norm = numpy.linalg.norm( diff, ord=2, axis=1 )
            cost = numpy.divide( norm, n )

        elif (costMetric == "Linf"):
            cost = numpy.linalg.norm( diff, ord=math.inf, axis=1 )

        else:   # Error: Cost metric not defined
            raise ValueError("cost_metric not defined")


        # Create dataframe with this trial's results
        resultsThisTrial = xInit.copy( deep=True )  # Initialize with parameters
        resultsThisTrial["cost"]  = cost            # Add cost
        resultsThisTrial["trial"] = numpy.full( (m,1), i )  # Add trial id
        resultsThisTrial = pandas.concat( [resultsThisTrial, ySim], axis=1 )
                                                    # Add simulation results

        # Update unsortedResults
        if (i!=0):
            unsortedResults =pandas.concat( [unsortedResults, resultsThisTrial],
                                            ignore_index=True
                                           )
        else:
            unsortedResults = resultsThisTrial.copy( deep=True )


    # Sort results (from best to worst)
    results = unsortedResults.sort_values( by=["cost"] )


    # Finalize and return
    return results
