#!/usr/bin/env python

import yaml
import argparse, textwrap
import os
import pandas
import numpy as np

"""
Tools for selecting samples based on an observation model defined in the
configuration file (or dict). It is designed to operate on a line list (tree
independent). It can save the sampled line list to a file or give a list of
sampled IDs so other programs that use the observed data can skip reading from
disk and maintain the full transmission tree (line list) before applying the
sample.

The yaml file defining the observation model (probability distribution) should
be formatted as follows:

There are three top level categories: files, dataRequested, samplingFrame.
'files' is optional and have have two things underneath it. The first is
'infectionLineListFilename' which is fulled by the name of a file containing
the line list to be used. The second 'observedLineListFilename' and is the name
to be used if writing out the sampled line list to a file.
'dataRequested' is required and can have two things underneath it. The first,
'numSamples' is required and gives the number of samples to draw. Currently,
there is no checks for if this number is larger then the number of rows in the
line list or even large enough that we may "run out" of some groups we are
sampling from. The second, fields, is optional and only matters if writing the
sampled line list to a file. It is a list of column names indicating which
columns to keep.
The last of the top three categories, samplingFrame, is also required and is
the most complicated because it sets up the observation model. We have also
tried to make it flexible so the same sampling scheme can be asked for in 
different ways. At a minimum under samplingFrame two entries are required,
'variable' naming a column to sample on and 'levels' giving a list of values
found in that column that we want in our sample. 'levels' can also be a 
dictionary with the keys being the levels and the values being the probability
of sampling that level. If there is one more key then value the keys will be
treated as bin edges instead of discrete values. In addition to these two
entries there are three others that can be given. The first is 'probability' a
list of values specifying the probabilities for sampling each entry in 'levels'
(if 'levels' is given as a list). If 'probability' is one shorter then 'levels'
then the values in 'levels' is treated as bin edges instead of discreet values.
The second is 'probabilityModel' which can contain a number of entries to
define the probability model to use in sampling from this variable. It can have
three types of entries. The first is 'type' which specifies the probability
distribution to use and can be given as: proportionalRandomSample (default),
uniformRandomSample, and list (assumed in 'probability' is given). The second
is 'probability' this is an alternative way to pass a list of values
specificying how to sample from this variable. If it is provided 'list' is the
assumed 'type'. If 'probability' is given on the same indentation level as
'probabilityModel' it will overwrite any given under 'probabilityModel'. The
last type of entry is a varibale name followed my a list of two numeric values.
This will be interrupted that you only want to sample from <variable> bewteen
the provided values. The last entry that can be directly under 'samplingFrame'
is a value that appears in 'levels'. This marks the beginning of a
sub-samplingFrame allowing us to specify how to sample from variable when it
equals a specific value, and can have the same entries as 'samplingFrame'.

The above is probably hard to read and understand so here are some examples to
explain.

files:                                    #optional
    infectionLineListFilename: <filename> #optional. Name of csv file name to
                                          #read in as line list
    observedLineListFilename: <filename>  #optional. Name of file to write
                                          #sampled line list to

dataRequested:                     #required
    numSamples: <int>              #required. Number of samples to take
    fields: <list of column names> #optional. Name of columns to keep if writing
                                   #out sampled line list

samplingFrame:                #required
    variable: <name of column
               in line list>  #required. Variable to condition sampling on
    levels: <list or dict>    #required. At a minimum this is a list of values
                              #the variable can be and are we want in our
                              #sample. If there are possible variable values
                              #not in this list no row with that value will be
                              #in the sample. If no other entries are specified
                              #we will sample from this list according to the
                              #how often they appear in the line list. If levels
                              #is given as a dictionary the values of the
                              #variable should be the keys and the dict values
                              #specify the probability of drawing the key. It is
                              #assumed that the variable takes on discreet values
                              #unless the number length of levels is one longer
                              #then the probilities then levels are treated as
                              #bin edges.
    probability: <list>       #optional. A list of probabilities specifying how
                              #many draws for each variable value to make
                              #(stotasticly). It should be the same length as
                              #the levels list (discreet levels) or one shorter
                              #(for bin edges). It is redundent with levels as
                              #a dictionary and/or probability given in the
                              #probabilityModel. Only one should be used and I
                              #think that this is the one that survives if the
                              #probability values are given in multiple ways.
    probabilityModel:         #optional
        type: <'proportionalRandomSample', #optional. Specifies the
               'uniformRandomSample',      #distribution used for drawing
               or 'list'>                  #the sample. proportional is the
                                           #default but if probability is given
                                           #(here, up one level, or through the
                                           #'levels' dict) list is assumed
        probability: <list>                #optional. List of probabilities for
                                           #drawing from variable's values (see
                                           #above)
        <variable value>: [min, max]       #for a numeric variable we can
                                           #specify a range from which we want
                                           #to sample excluding everything
                                           #outside this range. For example
                                           #excluding all infections before
                                           #some minimum time but before
                                           #another time
    <variable value>:         #optional. We can specify how to sample from the
                              #variable when it has a certain value from the
                              #'levels' list (or keys). Under this entry we can
                              #specify how to sample using all the entries that
                              #are used above (variable, levels, etc.) and
                              #continue this "subsampling" as many times as we
                              #want. If levels are bin edges instead of
                              #discreet values, then this 'value' should be the
                              #lower bin edge values, then this 'value' should be the
                              #lower bin edge.

"""

def prune(config, lineList):
    """
    Pruning involves removing lines that do not have a level (or bin) that is
    listed in the "level" section the sampling frame (not sampled). This
    function sets up this "pruning" process (creates the indictor column for
    dropping rows and move us into the "sampling frame" part of the config),
    calls the recursive function that marks rows for removal, and then does the
    actually removal.

    Args:
        config (dict)       : A dictionary containing the configuration. This
                              configuration needs to have an entry for the
                              "samplingFrame" which gives information on what
                              variables we are going to sample on and what
                              values they should have.
        lineList (dataframe): The line list we are sampling from. It is
                              (potentially) changed by this function.

        Returns:
            none            : The line list passed in is edited in place.

    """

    # create a column for indicating which rows so be dropped and set it to
    # false (no rows dropped)
    lineList["drop"] = 0

    # call the (recursive) function to mark rows for droping
    r_prune(config["samplingFrame"], lineList, np.ones(len(lineList["timeInfected"])))

    # drop rows that have been mark for it
    lineList.drop(lineList.index[lineList["drop"]==1], inplace=True)

    # remove our indicator column
    del lineList['drop']

    return

def r_prune(config, lineList, idx):
    """
    Pruning involves removing lines that do not have a level (or bin) that is
    listed in the "level" section the sampling frame (not sampled). This
    function recursively marks rows for removal if they do not a variable value
    that is in the expected (or sampled) value list or range.

    Args:
        config (dict)       : A dictionary containing the configuration. This
                              configuration needs to have an entry for the
                              "samplingFrame" which gives information on what
                              variables we are going to sample on and what
                              values they should have.
        lineList (dataframe): The line list we are sampling from. It is
                              (potentially) changed by this function.
        idx (array)         : An array that is accumulating all of the rows
                              that are marked for removal. I do not think this
                              is actually needed and will be looking into
                              removing it.

        Returns:
            none            : The line list passed in is edited in place.

    """

    # check if the probability model has been defined
    if "probabilityModel" in config:
        # Get a list of keys in the probability model
        keys = list(config["probabilityModel"])
        # Remove the two keys that are cannot be variables in the metadata
        if "type" in keys:
            keys.remove("type")
        if "probability" in keys:
            keys.remove("probability")

        # Loop through variables to remove values outside of the given range
        # Here we are expecting that any 'variable' listed in the probability
        # model have a contingous range of values we are sampling from and the
        # board is given as a ordered list [lowerBound, upperBound].
        for variableName in keys:
            idx_temp = np.logical_and(idx, lineList[variableName]<config["probabilityModel"][variableName][0])
            lineList.loc[idx_temp, ["drop"]] = 1
            idx_temp = np.logical_and(idx, lineList[variableName]>=config["probabilityModel"][variableName][1])
            lineList.loc[idx_temp, ["drop"]] = 1
    # create a key for the probability model if it does not already exist
    else:
        config["probabilityModel"] = {}

    # if the distribution is given as a dictionary break into two lists
    if type(config["levels"]) is dict:
        # get the probability values
        probability = list(config['levels'].values())
        # move the probability values into the probability model and remove
        # missing values
        config["probabilityModel"]["probability"] = [i for i in probability if i != None]
        # replace the 'levels' dictions with just the list of names (keys)
        config["levels"] = list(config['levels'].keys())

    # check for probability in current location (same level as probability
    # model and levels) and move to probabilityModel
    if "probability" in config:
        config['probabilityModel']['probability'] = config['probability']
        config.pop('probability')

    # check that levels and probabilities lists have the righ lengths
    if 'probability' in config['probabilityModel']:
        len_diff = len(config['levels']) - len(config['probabilityModel']['probability'])
        # if there is one more level then probabability value assume the levels
        # are bin edges
        if len_diff == 1:
            # check that the values in probability are numeric not sure if this
            # check is still needed
            if all(isinstance(x, (int, float)) for x in config['probabilityModel']['probability']):
                print('Number of levels and number of probabilites are off by one.')
                print('Assuming levels are bin edges.')
                bins = config['levels']
                # check if there are values outside of the provided bin edges
                # if so add the appropreiate bin(s). These extra bin(s) will
                # not be in levels so will be droped from the line list.
                min_value = lineList[config['variable']].min()
                if min_value < min(bins):
                    bins = [min_value] + bins
                max_value = lineList[config['variable']].max()
                if max_value > max(bins):
                    bins = bins + [max_value]
                lineList[config['variable']+'_bin'] = pandas.cut(lineList[config['variable']], bins, right=False, labels=bins[:-1])
                config['variable'] = config['variable']+'_bin'
                # drop the extra bins and have the lower edge define the bin
                config['levels'] = config['levels'][:-1]
            else:
                print('Number of levels and number of probabilites do not much up.')
                exit(-1)
        elif len_diff != 0:
            print('Number of levels and number of probabilites do not much up.')
            exit(-1)


    # mark inelibgible levels/bins for drapping
    if 'variable' in config:
        idx_temp = np.logical_and(idx, np.logical_not(np.in1d(lineList[config['variable']], config["levels"])))
        lineList.loc[idx_temp, ["drop"]] = 1
    else:
        return

    # iterate over level (sub categories)
    # get the list of keys and remove the three that are not variable names
    subCategories = list(config.keys())
    if 'variable' in subCategories: subCategories.remove('variable')
    if 'levels' in subCategories: subCategories.remove('levels')
    if 'probabilityModel' in subCategories: subCategories.remove('probabilityModel')
    # iterate through the variables
    for i in subCategories:
        idx_temp = np.logical_and(idx, np.in1d(lineList[config['variable']], i))
        r_prune(config[i], lineList, idx_temp)

    return

def distribution(config):
    """
    We are going to recursively check that the type of probability model is
    known and set if missing. This function just sets up the recursive call.

    Args:
        config (dict)       : A dictionary containing the configuration. This
                              configuration needs to have an entry for the
                              "samplingFrame" which gives information on what
                              variables we are going to sample on and what
                              values they should have.

        Returns:
            none            : The configuration dictionary is edited in place.

    """

    r_distribution(config["samplingFrame"], "samplingFrame")

    return

def r_distribution(config, category):
    """
    Recursively check that the type of probability model is known and set if
    missing.

    Args:
        config (dict)       : A dictionary containing the configuration. This
                              configuration needs to have an entry for the
                              "samplingFrame" which gives information on what
                              variables we are going to sample on and what
                              values they should have.

        Returns:
            none            : The configuration dictionary is edited in place.

    """


    # set probability model type to proportionalRandomSample if no type is
    # provided
    if not "type" in config["probabilityModel"]:
       if "probability" in config["probabilityModel"]:
           config["probabilityModel"]["type"] = "list"
       else:
           config["probabilityModel"]["type"] = "proportionalRandomSample"
           print("No probability model type given for", category, "assuming proportional distribution")

    # check that the type is one of the supported distributions
    if not ("proportionalRandomSample" in config["probabilityModel"]["type"] or
            "uniformRandomSample" in config["probabilityModel"]["type"] or
            "list" in config["probabilityModel"]["type"]):
        print("Only proportionalRandomSample, uniformRandomSample, and list are implemented for the top level probability")
        exit(-1)

    # iterate over level (sub categories)
    # get the list of keys and remove the three that are not variable names
    subCategories = list(config.keys())
    if 'variable' in subCategories: subCategories.remove('variable')
    if 'levels' in subCategories: subCategories.remove('levels')
    if 'probabilityModel' in subCategories: subCategories.remove('probabilityModel')
    # iteration over the variables
    for i in subCategories:
        r_distribution(config[i], i)

    return

def set_weights(config, lineList):
    """
    We need to recursively set up the weights used for drawing the sample. Each
    person's weight will be the probability of selecting the group they are in
    divided by the number of people in that group. This function just sets up
    the recursive call. Creating columns for the weights and size of each group
    then after making the call to the recursive function dividing weight by
    the group size.

    Args:
        config (dict)       : A dictionary containing the configuration. This
                              configuration needs to have an entry for the
                              "samplingFrame" which gives information on what
                              variables we are going to sample on and what
                              values they should have.
        lineList (dataframe): The line list we are sampling from. It is
                              (potentially) changed by this function.

        Returns:
            none            : The line list is edited in place.

    """


    # Initialize everyone's weights to 1 and everyones group size to the total
    # population size.
    lineList['Weights'] = 1
    lineList['GroupSize'] = len(lineList['Weights'])

    # call the recursive function
    r_set_weights(config["samplingFrame"], lineList, np.ones(len(lineList["Weights"])))

    # After recursively calculating the weights and group size divide the
    # weights by groupSize to get the final weights
    lineList['Weights'] *= 1/lineList['GroupSize']

    return

def r_set_weights(config, lineList, idx):
    """
    Recursively set up the weights used for drawing the sample by dividing each
    group into its sub groups (or each level into its sub categories). Then
    Update the weight and group size based on the probability model and size of
    the group.

    Args:
        config (dict)       : A dictionary containing the configuration. This
                              configuration needs to have an entry for the
                              "samplingFrame" which gives information on what
                              variables we are going to sample on and what
                              values they should have.
        lineList (dataframe): The line list we are sampling from. It is
                              (potentially) changed by this function.
        idx (array)         : An array that is accumulating all of the rows
                              that are marked for removal.

        Returns:
            none            : The line list is edited in place.

    """

    # if no feature ("variable") was give leave the weight proportional to
    # group size
    if not "variable" in config:
        return

    # if sampling proportionally set up probabilities for each group
    if "proportionalRandomSample" in config["probabilityModel"]["type"]:
        config["probabilityModel"]["probability"] = [1]*len(config["levels"])
        for i in range(len(config["levels"])):
            idx_temp = np.logical_and(idx, np.in1d(lineList[config['variable']], config["levels"][i]))
            config["probabilityModel"]["probability"][i] = sum(idx_temp)/sum(idx)
    # if sampling uniformly set up probability to be equal for each group
    elif "uniformRandomSample" in config["probabilityModel"]["type"]:
        config["probabilityModel"]["probability"] = [1]*len(config["levels"])
    # if a list of probabilities is provided make sure it is normalized
    else:
        config["probabilityModel"]["probability"] = [i/sum(config["probabilityModel"]["probability"]) for i in config["probabilityModel"]["probability"]]

    # set group probabilities and update group size
    for i in range(len(config["levels"])):
        idx_temp = np.logical_and(idx, np.in1d(lineList[config['variable']], config["levels"][i]))
        lineList.loc[idx_temp, ["Weights"]] *= config["probabilityModel"]["probability"][i]
        # use max to avouid dividing by zero if a group has no one in it
        lineList.loc[idx_temp, ["GroupSize"]] = max(sum(idx_temp), 1)
        # iterate over subcategories if they exist
        if config["levels"][i] in config:
            r_set_weights(config[config["levels"][i]], lineList, idx_temp)


def runObservationModel(config, return_ids=None, lineList=None):
    """
    This is the main function for getting samples and can be thought of as the
    the observation model. Based on the information in the configuration this
    function will draw a certain number of lines from a line list based on a
    probability distribution. It will then either right the reduced line list
    to a file (functionality that will go away) or return a list of ids of the
    chosen lines.

    Args:
        config (str or dict): The name of a yaml file containing the
                              configuration for the observation model (number
                              of sampling and probability distribution)
                              alternatively a dictionary equivalent to what
                              would be read in from a yaml file can be passed
        return_ids (str)    : Optional. The name of the column that contains 
                              the infection ID. If this is provided only a list
                              of IDs for the sampled infections are returned
                              otherwise the whole (downsampled) line list is
                              written to a file (file name should be in the
                              config).
        lineList (dataframe): Optional. The line list to sample from. If one is
                              not provided then there should be a file name of
                              one in the configuration to be read in.

        Returns:
            list            : If a value is given for return_ids, then that
                              column is returned from the down sampled line
                              list. If return_ids is not given then the down
                              sampled line list is written to file using the
                              file name that should be in the configuration.
    """

    # read in config if a file name was passed in.
    if not type(config) is dict:
        config = yaml.load(open(config), Loader=yaml.FullLoader)

    # if line list was not passed in read it from a file
    if lineList is None:
        lineList = pandas.read_csv(config["files"]["infectionLineListFilename"], na_filter=False)
    else:
        lineList = lineList.copy(deep=True)

    # prune ineligible levels and bins
    prune(config, lineList)

    # check probability models
    distribution(config)

    # setup probabilities
    set_weights(config, lineList)

    # select samples
    observeLineList = lineList.sample(n=config["dataRequested"]["numSamples"], weights="Weights")
    # reduce columns if requested
    if 'fields' in config['dataRequested']:
        observeLineList = observeLineList[config["dataRequested"]["fields"]]

    # if return_ids is provided (or no file name give) return a list of the sampled IDs
    if return_ids or not 'observedLineListFilename' in config['files']:
        if not return_ids:
            return_ids = 'id'
        return observeLineList[return_ids]
    # write down sampled line list to a file
    else:
        # check for the output directory and create if it doesn't exist
        try:
            directory = os.path.dirname(config["files"]["observedLineListFilename"])
            if not directory == '':
                os.makedirs(directory)
        except OSError:
            if not os.path.isdir(directory):
                raise
        observeLineList.to_csv(config["files"]["observedLineListFilename"], index=False)
        #write out full lineList with weights for testing and debuging
        #lineList.to_csv('testWeights.csv', index=False)

    return


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
            prog='observation_model_prototype',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            description="Python Code for Observation Models")
    parser.add_argument('--config', '-C', metavar='CONFIG_FILE_NAME', help="config file name", default="configObserve.yaml")
    input_args = parser.parse_args()


    runObservationModel(input_args.config)
