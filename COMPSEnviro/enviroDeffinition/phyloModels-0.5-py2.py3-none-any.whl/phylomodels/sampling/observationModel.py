#!/usr/bin/env python

from __future__ import print_function
from builtins import range
import yaml
import argparse, textwrap
import os
import pandas
import numpy as np

"""Tools for selecting samplings based on the the observation model
defined in the configuration file. It is designed to operate on a
line list. It can out the sampled line list to a file (current) or
give a list of sampled IDs (in progress) so other programs that
use the observed data can skip reading from disk."""

def prune(config, lineList):
    """Remove those that are outside our observation parameters (time, location, ect.)."""

    lineList["drop"] = 0
    r_prune(config["samplingFrame"], lineList, np.ones(len(lineList["timeInfected"])))
    lineList.drop(lineList.index[lineList["drop"]==1], inplace=True)
    del lineList['drop']
    return

def r_prune(config, lineList, idx):
    """Recursively remove all those that lay outside of the observation parameters."""

    if "probabilityModel" in config:
        if "timeInterval" in config["probabilityModel"]:
            #prune lineList of ineligible times for the current level
            idx_temp = np.logical_and(idx, lineList['timeInfected']<config["probabilityModel"]["timeInterval"][0])
            lineList.loc[idx_temp, ["drop"]] = 1
            idx_temp = np.logical_and(idx, lineList['timeInfected']>config["probabilityModel"]["timeInterval"][1])
            lineList.loc[idx_temp, ["drop"]] = 1
    else:
        config["probabilityModel"] = {}
    #prune inelibgible levels
    if "type" in config:
        idx_temp = np.logical_and(idx, np.logical_not(np.in1d(lineList[config["type"]], config["levels"])))
        lineList.loc[idx_temp, ["drop"]] = 1
    else:
        return

    #iterate over level (sub categories)
    subCategories = list(config.keys())
    if 'type' in subCategories: subCategories.remove('type')
    if 'levels' in subCategories: subCategories.remove('levels')
    if 'probabilityModel' in subCategories: subCategories.remove('probabilityModel')
    for i in subCategories:
        idx_temp = np.logical_and(idx, np.in1d(lineList[config["type"]], i))
        r_prune(config[i], lineList, idx_temp)

    return

def distribution(config):
    """Set up a single list of probabilities for drawing samples from each group"""
    r_distribution(config["samplingFrame"], "samplingFrame")

    return

def r_distribution(config, category):
    """Recursively build the probability distribution"""

    #set probability model type if missing
    if not "type" in config["probabilityModel"]:
       if "probability" in config["probabilityModel"]:
           config["probabilityModel"]["type"] = "list"
       else:
           config["probabilityModel"]["type"] = "uniformRandomSample"
           print("No probability model type given for", category, "assuming uniform distribution")

    #check for supported distribution
    if not ("uniformRandomSample" in config["probabilityModel"]["type"] or "list" in config["probabilityModel"]["type"]):
        print("Only uniformRandomSample and list are implemented for the top level probability")
        exit(-1)

    #iterate over level (sub categories)
    subCategories = list(config.keys())
    if 'type' in subCategories: subCategories.remove('type')
    if 'levels' in subCategories: subCategories.remove('levels')
    if 'probabilityModel' in subCategories: subCategories.remove('probabilityModel')
    for i in subCategories:
        r_distribution(config[i], i)

    return

def set_weights(config, lineList):
    """Set up the weights for drawing a sample. Each persons weight will be
    the probability of selecting the group they are in divided by the number
    of people in that group."""

    #Initialize everyone's weights to 1 and everyones group size to the
    #total population.
    lineList['Weights'] = 1
    lineList['GroupSize'] = len(lineList['Weights'])

    r_set_weights(config["samplingFrame"], lineList, np.ones(len(lineList["Weights"])))

    #After recursively calculating the weights and groupSize divide the
    #weights by groupSize to get the final weights
    lineList['Weights'] *= 1/lineList['GroupSize']

    return

def r_set_weights(config, lineList, idx):
    """Calculate the weights and groupSize recursively by dividing
    each group into its sub groups (or each level into its sub
    categories)."""

    #if no feature ("type") was give leave the weight uniform
    if not "type" in config:
        return

    #if sampling uniformly set up probabilities for each group
    if "uniformRandomSample" in config["probabilityModel"]["type"]:
        config["probabilityModel"]["probability"] = [1]*len(config["levels"])
        for i in range(len(config["levels"])):
            idx_temp = np.logical_and(idx, np.in1d(lineList[config["type"]], config["levels"][i]))
            config["probabilityModel"]["probability"][i] = sum(idx_temp)/sum(idx)
    else:
        #make sure probability list is normalized
        config["probabilityModel"]["probability"] = [i/sum(config["probabilityModel"]["probability"]) for i in config["probabilityModel"]["probability"]]

    #set group probabilities and update group size
    for i in range(len(config["levels"])):
        idx_temp = np.logical_and(idx, np.in1d(lineList[config["type"]], config["levels"][i]))
        lineList.loc[idx_temp, ["Weights"]] *= config["probabilityModel"]["probability"][i]
        #use max to avouid dividing by zero if a group has no one in it
        lineList.loc[idx_temp, ["GroupSize"]] = max(sum(idx_temp), 1)
        #iterate over subcategories if they exist
        if config["levels"][i] in config:
            r_set_weights(config[config["levels"][i]], lineList, idx_temp)


def runObservationModel(config, return_ids=False, lineList=None):
    """Run the observation model.
    If you want the sampled ids instead of having the samples written
    to disk set retutrn_ids to True. If you would like to pass in
    the line list instead of reading it from file that is also an
    option."""

    #read config
    if not type(config) is dict:
        config = yaml.load(open(config), Loader=yaml.FullLoader)


    #reading in data
    if lineList is None:
        lineList = pandas.read_csv(config["files"]["infectionLineListFilename"], na_filter=False)

    #prune ineligible times and categories
    prune(config, lineList)

    #check probability models
    distribution(config)

    #setup probability
    set_weights(config, lineList)

    #select samples and fields
    observeLineList = lineList.sample(n=config["dataRequested"]["numSamples"], weights="Weights")
    if 'fields' in config['dataRequested']:
        observeLineList = observeLineList[config["dataRequested"]["fields"]]

    if return_ids or not 'observedLineListFilename' in config['files']:
        return observeLineList["id"]
    else:
        #write samples to file
        #check output directory and create if it doesn't exist
        try:
            directory = os.path.dirname(config["files"]["observedLineListFilename"])
            if not directory == '':
                os.makedirs(directory)
        except OSError:
            if not os.path.isdir(directory):
                raise
        observeLineList.to_csv(config["files"]["observedLineListFilename"], index=False)
        #write out full lineList with weights for testing and debuging
        #lineList.to_csv('testWeights.csv', index=False)

    return


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
            prog='observation_model_prototype',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            description="Python Code for Observation Models")
    parser.add_argument('--config', '-C', metavar='CONFIG_FILE_NAME', help="config file name", default="configObserve.yaml")
    input_args = parser.parse_args()


    runObservationModel(input_args.config)
