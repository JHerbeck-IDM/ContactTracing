def is_bifurcating(tree):
    """
    Check if a tree is bifurcating.

    Args:
        tree (Tree)      : The tree to check for bifuraction.

    Returns:
        boolean          : True if the tree is bifurcating.
    """

    # Start with a true value
    bifurcating = True
    
    # Check the number of children each node has
    for node in tree.traverse('levelorder'):
        children = tree.children
        if (len(children) != 0 or len(childern) != 2):
            return False
    
    return bifurcating
