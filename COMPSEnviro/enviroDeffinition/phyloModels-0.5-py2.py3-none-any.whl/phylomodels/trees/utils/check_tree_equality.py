import numpy as np

def is_number(string):
    """
    A function to check if a string is a number.
    isnumeric only checks if it is an interger, this is broader.

    Args:
        string (str): String to check

    Returns:
        boolean    : Whether the string was converted to a float
    """
    
    try:
        float(string)
        return True
    except ValueError:
        return False
    
def check_tree_equality(tree1, tree2):
    """
    Check if two trees are equivelant.
    TODO Add options for the level of identity needed (attribute values or just topology)

    Args:
        tree1 (Tree)      : One of  the trees to compare.
        tree2 (Tree)      : The other tree to compare.

    Returns:
        boolean           : Whether the topology and all attrs were equal.
    """

    # Start with a true value
    equality = True
    
    # Check that they have the same features
    features1 = tree1.features
    features2 = tree2.features
    if features1 != features2:
        print(tree1.name, ' and ', tree2.name, ' did not have the same features')
        print(tree1.features)
        print(tree2.features)
        return False
    
    # Check that the feature values are the same
    for feature in features1:
        value1 = getattr(tree1, feature)
        # Check if the value is a string and if it should be converted to a number
        if isinstance(value1, str):
            if is_number(value1):
                value1 = float(value1)
        value2 = getattr(tree2, feature)
        if isinstance(value2, str):
            if is_number(value2):
                value2 = float(value2)
        # If the values are float check for numeric equality
        #TODO add ability to choose tolerences
        if isinstance(value1, float):
            denom = max(value1, value2, 1e-6)
            if not (abs(value1-value2)/denom < 1e-6 or abs(value1-value2) < 1e-8):
                print(feature)
                print(tree1.name, ': ', value1, ' ', tree2.name, ': ', value2)
                return False
        # If they are not floats we should be able to directly compare.
        else:
            if value1 != value2:
                print(feature)
                print(tree1.name, ': ', value1, ' ', tree2.name, ': ', value2)
                return False
        
    # Check that they have the same children
    children1 = tree1.children
    children2 = tree2.children
    children_names1 = []
    for child in children1:
        children_names1.append(child.name)
    children_names2 = []
    for child in children2:
        children_names2.append(child.name)
    if set(children_names1) != set(children_names2):
        print('Children are different')
        print(tree1.name, ': ', children_names1, ' ', tree2.name, ': ', children_names2)
        return False
    
    # Check that children are the same
    idx1 = np.argsort(children_names1)
    idx2 = np.argsort(children_names2)
    for i in np.arange(len(idx1)):
        equality = check_tree_equality(children1[idx1[i]], children2[idx2[i]]) and equality
    
    return equality
