import numpy as np
import pandas as pd
from ete3 import Tree
from phylomodels.trees.utils.calculate_branch_lengths import calculate_branch_lengths

def add_childrenFromLineList(node, lineList, ID, infectorID, infectTime,
                             sampleTime, features):
    """
    Use the line list to find all the people infected by the current tree node
    and add them as children.

    Args:
        node (TreeNode)     : The node of the tree that contains the current
                              infector.
        lineList (dataframe): The list line that includes who infected whom 
                              (edge list).
        ID (str)            : The name of the column containing the ID or name
                              of who was infected.
        infectorID (str)    : The name of the column containing the ID or name
                              of the source of the infection.
        infectTime (str)    : The name of the column containing the time of
                              infection.
        sampleTime (str)    : Optional (default None). The name of the column 
                              containing the time of sampling (if sampled).
        features (list)     : Optional (default None). List of features to add
                              to the tree from the line list. An empty list
                              ([]) will add all features.

    Returns:
        times (list)        : This function directly modifies the tree through 
                              the node that is passed. However it also returns
                              a list of branch length to help estimate the
                              time of infection for the root.

    """

    node_name = node.name
    children = lineList.loc[lineList[infectorID]==node_name, ID]
    times = []
    for child_name in children:
        child = node.add_child(name=child_name)
        idx = lineList[ID]==child_name
        child.add_feature('time', lineList.loc[idx, infectTime].values[0])
        child.add_feature('infectTime', lineList.loc[idx, infectTime].values[0])
        if sampleTime:
            time = lineList.loc[idx, sampleTime].values[0]
            child.add_feature('sampleTime', time)
        if features:
            for feature in features:
                child.add_feature(feature, lineList.loc[idx, feature].values[0])
        # Make sure the parent has an time
        parent_time = min(getattr(node,'time', child.time), child.time)
        node.add_feature('time', parent_time)
        times.append(child.time-getattr(node, 'time', child.time))
        temp_times = add_childrenFromLineList(child, lineList, ID, infectorID,
                                              infectTime, sampleTime, features)
        times = times+temp_times
        
    return times


def read_treeFromLineList(lineList, **kwargs):
    """
    Return a list of (transmission) trees read in from a line list that has
    information on who infected whom and when. The file is assumed to be stored
    is CSV format and is read into a pandas dataframe. The resulting data from
    needs to have at least three columns one containing a name or ID for the 
    infection (default name id), one containing a nome or ID for the infector
    (default name infectedById), and one containing the time of infection.
    This data is then used to create the (transmission) tree and calculate the
    branch lengths (time not genetic distance).

    Args:
        lineList (dataFrame): The name of the CSV file from which we will read
                              the edge list.
        ID (str)            : Optional (default 'id'). The name of the column
                              containing the ID or name of who was infected.
        infectorID (str)    : Optional (default 'infectedById'). The name of
                              the column containing the ID or name of the
                              source of the infection.
        infectTime (str)    : Optional (default 'timeInfected'). The name of
                              the column containing the time of infection.
        sampleTime (str)    : Optional (default None). The name of the column 
                              containing the time of sampling (if sampled).
        features (list)     : Optional (default None). List of features to add
                              to the tree from the line list. An empty list
                              ([]) will add all features.
        branchLengths (bool): Optional (default True). Whether or not to
                              calculate branch lengths after reading in the
                              tree.

    Returns:
        list (trees)        : A list of ete3 trees generated from the edge list.
                              The reason it is a list of trees instead of just
                              a single tree is because there may be more then
                              one seed infection. There are other functions for
                              joining the trees if needed.

    """

    # Get Optional arguements
    ID         = kwargs.pop('ID', 'id')
    infectorID = kwargs.pop('infectorID', 'infectedById')
    infectTime = kwargs.pop('infectTime', 'timeInfected')
    sampleTime = kwargs.pop('sampleTime', None)
    features   = kwargs.pop('features', None)
    branchLengths = kwargs.pop('branchLengths', True)
    #TODO add an option for sample time?
    #TODO add an option for other features from the line list to annotate
    # the tree with?
    
    if hasattr(features, '__len__') and len(features)==0:
        features = list(lineList.columns)
    # Cast any numeric IDs to strings to avoid pontential issues
    # Also change characters that have meaning in newick format
    lineList[ID] = lineList[ID].astype(str)
    lineList[ID] = lineList[ID].str.replace(':', '_')
    lineList[ID] = lineList[ID].str.replace(',', '-')
    lineList[ID] = lineList[ID].str.replace(';', '+')
    lineList[infectorID] = lineList[infectorID].astype(str)
    lineList[infectorID] = lineList[infectorID].str.replace(':', '_')
    lineList[infectorID] = lineList[infectorID].str.replace(',', '-')
    lineList[infectorID] = lineList[infectorID].str.replace(';', '+')
    #TODO I should do some type checking for the time column so we can handle both numeric values and dates

    # Initial empty list of trees
    trees = []
    
    # Find IDs that infect but are never infected (the roots)
    roots = set(lineList[infectorID]) - set(lineList[ID])
    # Loop there all the roots and recursively build the trees
    for root in roots:
        # Create a tree for each root/seed/importation
        temp_tree = Tree(name=root)
        # Call the recursive add function
        times = add_childrenFromLineList(temp_tree, lineList, ID, infectorID,
                                         infectTime, sampleTime, features)
        times = np.array(times)
        # We do not have the time of infection for the seed cases/importations
        # so here we take a list of branch lengths and use its mean to estimate
        # the time of infection for the seed cases. We are flooring this value
        # at zero.
        temp_tree.add_feature('time', np.max([0, temp_tree.children[0].time - np.mean(times)]))
        temp_tree.add_feature('infectTime', np.max([0, temp_tree.children[0].time - np.mean(times)]))
        if len(temp_tree.children)==1:
            node = temp_tree
            temp_tree = node.children[0]
            node.delete()
        trees.append(temp_tree)

    if(branchLengths):
        calculate_branch_lengths(trees, inplace=True)
    
    return trees

def read_treeFromLineListFile(fileName, **kwargs):
    """
    Read in the line list CSV into a pandas data frame and pass it to the
    function that will actually build the tree.

    Args:
        fileName (str)      : The name of the CSV file from which we will read
                              the edge list.
    Returns:
        list (trees)        : A list of ete3 trees generated from the edge list.
                              The reason it is a list of trees instead of just
                              a single tree is because there may be more then
                              one seed infection. There are other functions for
                              joining the trees if needed
    """

    # Read the file in to a pandas data frame
    lineList = pd.read_csv(fileName)

    return read_treeFromLineList(lineList, **kwargs)

def generate_treeFromFile(fileName, fileType='newick', **kwargs):
    """
    Return a list of (transmission) trees read in from a file. Currently we can
    read in from a 'newick' (newick or NHX) style file or a line list that has
    information on who infected whom and when. There are various optional
    arguments depending on the format you are trying to read in.
    TODO add NeXML and PhyloXML support

    Args:
        fileName (str)      : The name of the file from which we will read the
                              tree.
        fileType (str)      : The name of the format used in the file you are
                              reading in. Currently the options are 'newick',
                              'NHX', or 'lineList'.
        format (int)        : Optional (default 1) for 'newick' or NHX. A value
                              form 0-9, or 100. See ete3 documents for meanings.
        ID (str)            : Optional (default 'id') for 'linelist'. The name
                              of the column containing the ID or name of who
                              was infected.
        infectorID (str)    : Optional (default 'infectedById') for 'linelist'.
                              The name of the column containing the ID or name
                              of the source of the infection.
        infectTime (str)    : Optional (default 'timeInfected') for 'linelist'.
                              The name of the column containing the time of
                              infection.
        sampleTime (str)    : Optional (default None) for 'linelist'. The name
                              of the column containing the time of sampling (if
                              sampled).
        features (list)     : Optional (default None) for 'linelist'. List of
                              features to add to the tree from the line list.
                              An empty list ([]) will add all features.
        branchLengths (bool): Optional (default True) for 'linelist'. Whether
                              or not to calculate branch lengths after reading
                              in the tree.

    Returns:
        list (trees)        : A list of ete3 trees generated from the edge
                              list. The reason it is a list of trees instead of
                              just a single tree is because there may be more
                              then one seed infection. There are other
                              functions for joining the trees if needed.

    """
    trees = []
    if (fileType.casefold() == 'newick'.casefold() or
           fileType.casefold() == 'NHX'.casefold()):
        # Allow users to pase in arguments for ete3.Tree
        newickFormat = kwargs.pop('format', 1)
        # If you are reading from a file (not creating the Tree from stratch) I
        # do not think you would use these options.
        dist = kwargs.pop('dist', None)
        support = kwargs.pop('support', None)
        name = kwargs.pop('name', None)
        trees.append(Tree(fileName), format=newickFormat, dist=dist, 
                     support=support, name=name)
    elif fileType.casefold() == 'linelist'.casefold():
        trees = read_treeFromLineListFile(fileName, **kwargs)
    else:
        print('ERROR: ', fileType, ' not a know tree format.')

    return trees
