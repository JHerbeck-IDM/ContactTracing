import numpy as np
import pandas as pd
from ete3 import Tree
from phylomodels.trees.utils.calculate_branch_lengths import calculate_branch_lengths
   
def transform_downSample(data_in, leaves_to_keep, **kwargs):
    """
    Taking a tree or dataframe from which a tree is built and down sample it.
    For the tree this means removing leaf nodes that are unsampled and ancester
    nodes as approperiate. For the line list this means removing the sampling
    time for nodes that are unsampled so when the tree is built we get the down
    sampled version.
    
    Args:
        data_in (Tree or dataframe): Ete3 tree or dataframe that will be a tree.
        leaves_to_keep (list-like) : List of node names that are to be kept as
                                     samples.
        inplace (boolean)          : Optional (default False). Whether to do an
                                     inplace downsample or return a copy of the
                                     changed input.
        ID (str)                   : Optional (default 'id', only used for
                                     dataframe input). The name of the column
                                     containing the ID or name of a node.
        sampleTime (str)           : Optional (default 'sampleTime', only used
                                     for dataframe input). The name of the column 
                                     containing the time of sampling.

    Returns:
        Tree or dataframe          : The donwsampled ete3 tree or dataframe.
                                     Unless inplace is choosen then there is no
                                     return.
        
    """
    
    inplace = kwargs.pop('inplace', False)
    if type(data_in) == pd.core.frame.DataFrame:
        ID = kwargs.pop('ID', 'id')
        sampleTime = kwargs.pop('sampleTime', 'sampleTime')
        if inplace:
            data_out = data_in.copy(deep=False)
        else:
            data_out = data_in.copy(deep=True)
        data_out.loc[~data_out[ID].isin(leaves_to_keep), sampleTime] = np.nan
    elif type(data_in) == Tree:
        if inplace:
            data_out = data_in
        else:
            data_out = data_in.copy('deepcopy')
        for node in data_out.get_leaves():
            # If it is not a sampled node we need to delete it then remove any
            # monotomies in its ancestory
            if node.name not in leaves_to_keep:
                up_node = node.up
                node.delete()
                while hasattr(up_node, 'children'):
                    temp = up_node.up
                    if len(up_node.children)==1:
                        up_node.delete()
                    up_node = temp
        if len(data_out.children) == 1:
            data_out = data_out.children[0]
            data_out.up.delete()

        calculate_branch_lengths([data_out], inplace=True)

    if not inplace:
        return data_out
