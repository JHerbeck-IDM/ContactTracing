import numpy as np
from phylomodels.trees.utils.calculate_branch_lengths import calculate_branch_lengths
from phylomodels.trees.utils.clone_node import clone_node
   
def transform_transToPhyloTree(tree_in, **kwargs):
    """
    Taking a tree (transmission tree) change the external branch lengths from
    the time between transmission to the time from transmission to sampling.
    This will make the external branch lengths represent the amount of time the
    sequences have had to diverage from the founding sequence.
    
    Args:
        tree_in (Tree)   : The ete3 tree to convert from a transmission tree to
                           a phylogenetic tree.
                    TODO add options around handling missing sampling times?

    Returns:
        Tree        : An ete3 tree containing the tree with converted external
                      branch lengths.
        
    """
    
    tree_out = tree_in.copy('deepcopy')
    nodes = [tree_out] + tree_out.get_descendants('levelorder')
    for node in nodes:
        # The do not start out sampled
        sampledYet = False
        # Was this person sampled
        if hasattr(node, 'sampleTime') and not np.isnan(node.sampleTime):
            # set sampled to true and get the sampleTime
            sampled = True
            sampleTime = node.sampleTime
            node.time = sampleTime
        else:
            # set sampled to false and set simpleTime to infinity
            # the sampling time is important for knowing which transmissions
            # happened after sampling. If a person is not sampled (or not
            # sampled yet) then all transmission happens before the sampling
            # so to make sure that happens we set sampleTime to infinity
            sampled = False
            sampleTime = float('inf')
        # We want to keep adding transmission and/or sampling nodes until the
        # infectee becomes a leaf node.
        while(not node.is_leaf()):
            # First find the earliest transmission from our current person
            children = node.children
            infect_time = np.zeros(len(children))
            for i in np.arange(len(children)):
                infect_time[i] = children[i].infectTime
            min_time = np.min(infect_time)
            children = np.array(children)
            # Only select the children that were transmitted at this time
            children = children[infect_time == min_time]
            # Create the new internal node with all the properties of the transmitter
            new_node = clone_node(node)
            # If this node is the root shift to new root
            if node.up is None:
                tree_out = new_node
            # check if sampling has pasted but there is not yet a sampled node
            if sampleTime <= children[0].infectTime and not sampledYet:
                # Create the "sample" internal node
                new_node.name = node.name+'_sample'
                new_node.add_feature('time', sampleTime)
                # We need to keep track of the last node we made so we can
                # add children to it.
                old_new_node = new_node
                # Add the sampled node as a sister to the current node and
                # then make the current node a child of its sampled node.
                if node.up:
                    node.up.add_child(new_node)
                node = node.detach()
                new_node.add_child(node)
                # Mark that we have now sampled this person
                sampledYet = True
            else:
            # we do not need a sample node make a tranmission node
                # If we have only one childen we do not want to create the
                # transmission node.
                if len(node.children) == 1 and sampledYet:
                    for child in children:
                        child.detach()
                        old_new_node.add_child(child)
                else:
                    # The new node represents the transmission event
                    new_node.name = node.name + '_infect_' + children[0].name
                    new_node.add_feature('time', children[0].infectTime)
                    # attach the new node to the right parent
                    if not sampledYet:
                        if node.up:
                            node.up.add_child(new_node)
                        node = node.detach()
                        new_node.add_child(node)
                    else:
                        old_new_node.add_child(new_node)
                        old_new_node = new_node
                    # move children to the new_node
                    for child in children:
                        child.detach()
                        new_node.add_child(child)

        # If it is not a sampled node we need to delete it after it becomes
        # leaf and then remove any monotomies in its ancestory
        if not sampled:
            up_node = node.up
            # if the tree has a single node that is not sampled
            if not node.up and len(node.children) == 0:
                return None
            node.delete()
            while hasattr(up_node, 'children'):
                temp = up_node.up
                if len(up_node.children)==1:
                    up_node.delete()
                up_node = temp

    # Iterate backwards through the tree removing leaves that where not sampled
    nodes = [tree_out] + tree_out.get_descendants('levelorder')
    for node in reversed(nodes):
        if node.is_leaf():
            if not getattr(node, 'sampleTime', None):
                if not node.up and len(node.children) == 0:
                    return None
                node.delete()

    # Make sure we do not have a node above the "root"
    if len(tree_out.children) == 1:
        tree_out = tree_out.children[0]
        tree_out.up.delete()

    calculate_branch_lengths([tree_out], inplace=True)

    return tree_out
